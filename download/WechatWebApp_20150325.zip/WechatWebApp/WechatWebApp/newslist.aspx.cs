﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Diagnostics;

namespace WechatWebApp
{
    public partial class newslist : System.Web.UI.Page
    {
        public String newshtml { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            DateTime today = DateTime.Today;
            String year = today.Year.ToString();

            if (Request.HttpMethod.ToLower() == "get" && HttpContext.Current.Request.QueryString["year"]!=null)
            {
                  year = HttpContext.Current.Request.QueryString["year"];

                  DropDownList1.ClearSelection();
                  DropDownList1.SelectedIndex = 3;
            }

            int thisYear = today.Year;

            for (int i = 0; i < 9; i++)
            {
                DropDownList1.Items.Add(new ListItem(thisYear.ToString(), thisYear.ToString(), true));
                thisYear--;
            }

            CustomBrowser browser = new CustomBrowser("http://sc.hkex.com.hk/TuniS/www.hkex.com.hk/chi/newsconsul/hkexnews/" + year + "news_c.htm");
            ArrayList news = browser.getHiddenPageByArrayList("News");
            
            String tempDate="";
            for (int i = 0; i < news.Count;i=i+2 )
            {
                if (tempDate!=news[i].ToString()){
                    newshtml += "<li class=\"daterow\">" + news[i] + "</li>\n";
                    tempDate = news[i].ToString();

                }
                 newshtml+="<li class=\"newsrow\">" + news[i+1] + "</li>\n";
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Response.Redirect("http://testing4wechat.cloudapp.net/wechat/newslist.aspx?year=" + DropDownList1.SelectedValue);
        }
    }
}