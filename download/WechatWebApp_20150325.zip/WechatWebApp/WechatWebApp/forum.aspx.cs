﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Collections;
using System.Windows.Forms;

namespace WechatWebApp
{
    public partial class forum : System.Web.UI.Page
    {
        public String forumHtml { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            String datestr = String.Format("{0:yyyy}", DateTime.Today);
            //String site = "http://testing4wechat.herokuapp.com/chi/newsconsul/app/forum";
            String site = "http://www.hkex.com.hk/chi/newsconsul/app/forum";
            CustomBrowser browser = new CustomBrowser(site + datestr + "_c.htm");
            ArrayList forumList = browser.getHiddenPageByArrayList("forum");

            String tempDate = "";
            for (int i = 0; i < forumList.Count; i = i + 2)
            {
                if (tempDate != forumList[i].ToString())
                {
                    forumHtml += "<li class=\"daterow\">" + forumList[i] + "</li>\n";
                    tempDate = forumList[i].ToString();
                }
                forumHtml += "<li class=\"forumrow\">" + forumList[i + 1] + "</li>\n";
            }
        }
    }

    
}