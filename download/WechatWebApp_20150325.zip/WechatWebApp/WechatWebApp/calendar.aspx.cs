﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using System.Text.RegularExpressions;

namespace WechatWebApp
{
    public partial class calendar : System.Web.UI.Page
    {
        //sb sh
        public String redPoint { get; set; }
        //nb sh
        public String bluePoint {get;set;}
        String site = "http://www.hkex.com.hk/chi/newsconsul/app/calendar_c.htm";
        String host = "http://testing4wechat.cloudapp.net/wechat/";
        protected void Page_Load(object sender, EventArgs e)
        {
            CustomBrowser browser = new CustomBrowser(site);

            ArrayList items = browser.getHiddenPageByArrayList("Calendar");

            redPoint = "<img src=\"images/SBSH.png\" height=\"15\" width=\"15\">  沪股通市圽关闭<br />";
            bluePoint = "<img src=\"images/NBSH.png\" height=\"15\" width=\"15\">  港股通市圽关闭<br /><br />";
           

            int selectedyear = 0;
            int selcetedmonth = 0;


            if (Request.HttpMethod.ToLower() == "get" && System.Web.HttpContext.Current.Request.QueryString["year"] != null && System.Web.HttpContext.Current.Request.QueryString["month"] != null)
            {
                selectedyear =int.Parse( System.Web.HttpContext.Current.Request.QueryString["year"]);
                selcetedmonth = int.Parse(System.Web.HttpContext.Current.Request.QueryString["month"]);
            }

             Dictionary<String, String> htmlItems=new Dictionary<String, String>();
             Dictionary<String, String> optionSet = new Dictionary<String, String>();
            ArrayList itemHtml =new ArrayList();
            String itemstr="";
            for (int i=0; i < items.Count;i=i+2 )
            {
                itemstr = "";
                //Boolean addedItem = false;
                int tempyear = int.Parse(findTheMatchValue(items[i].ToString(), @"-([0-9]{4,})", 1));
                int tempmonth = int.Parse(findTheMatchValue(items[i].ToString(), @"-([0-9]{2,2})", 1));
                int day = int.Parse(findTheMatchValue(items[i].ToString(), @"([0-9]{2,2})-", 1));

                if (selectedyear == 0)
                {
                    selectedyear = tempyear;
                    selcetedmonth = tempmonth;
                   
                }

                if (!optionSet.ContainsKey("?year=" + tempyear + "&month=" + tempmonth) && items[i + 1].ToString().ToLower() != "na")
                {
                    optionSet["?year=" + tempyear + "&month=" + tempmonth] = tempyear + " 年 " + tempmonth + " 月";
                }


                if (tempyear == selectedyear && tempmonth == selcetedmonth && items[i + 1].ToString().ToLower()!= "na")
                {

                    //suppose the date is descending 
                    if (items[i + 1].ToString().ToLower() == "sb sh")
                    {
                        itemstr += "<img src=\"images/SBSH.png\" height=\"15\" width=\"15\">";
                        if (htmlItems.Count != 0 && htmlItems.ContainsKey(tempmonth + "-" + day + "-" + tempyear) && htmlItems[tempmonth + "-" + day + "-" + tempyear] != null)
                        {

                            htmlItems[tempmonth + "-" + day + "-" + tempyear] += itemstr;
                       
                        }
                        else
                        {
                            htmlItems.Add(tempmonth + "-" + day + "-" + tempyear, itemstr);

                        }
                    }
                    if (items[i + 1].ToString().ToLower() == "nb sh")
                    {

                        itemstr += "<img src=\"images/NBSH.png\" height=\"15\" width=\"15\">";

                        if (htmlItems.Count != 0 && htmlItems.ContainsKey(tempmonth + "-" + day + "-" + tempyear) && htmlItems[tempmonth + "-" + day + "-" + tempyear] != null)
                         {
                             htmlItems[tempmonth + "-" + day + "-" + tempyear] += itemstr;

                         }
                         else
                         {
                             htmlItems.Add(tempmonth + "-" + day + "-" + tempyear, itemstr);
                         }
                       
                      
                    }

                }

                
            }


            Calendar1.VisibleDate = new DateTime(selectedyear, selcetedmonth, 1);

            foreach (KeyValuePair<string, string> entry in optionSet)
            {
                DropDownList1.Items.Add(new ListItem(entry.Value, entry.Key, true)); 
            }


           // DropDownList1.SelectedIndex = 1;
            
            DataTable dtEvents = new DataTable();
            dtEvents.Columns.Add(new DataColumn("EventDate", typeof(System.DateTime)));
            dtEvents.Columns.Add(new DataColumn("image",typeof(System.String)));
            

            foreach (KeyValuePair<string, string> entry in htmlItems)
            {
                string df = entry.Key;
                dtEvents.Rows.Add(Convert.ToDateTime(entry.Key),entry.Value);

            }

            ViewState["dtEvents"] = dtEvents;
            

        }

        


        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            

            if (ViewState["dtEvents"] != null)
            {
                DataTable dtEvents = (DataTable)ViewState["dtEvents"];
                foreach (DataRow oItem in dtEvents.Rows)
                {
                    if (Convert.ToDateTime(oItem["EventDate"]).ToString("dd-MM-yyyy") == e.Day.Date.ToString("dd-MM-yyyy"))
                    {
                        Literal ltrl = new Literal();
                        ltrl.Text = "<br>"+oItem["image"].ToString(); 
                        e.Cell.Controls.Add(ltrl);
                    }
                }
            }
        }


        public string findTheMatchValue(string htmlCode, string regexStr, int index)
        {

            
            Match m = Regex.Match(htmlCode, regexStr);
            if (m.Success)
            {
                return m.Groups[index].Value;
            }
            else
            {
                return "";
            }

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

            Response.Redirect(host+"calendar.aspx" + DropDownList1.SelectedValue);

        }


    }
}