﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Web.Security;



namespace WechatWebApp
{
    public partial class _Default : System.Web.UI.Page
    {        
        protected void Page_Load(object sender, EventArgs e)
        {
            Weixin wx = new Weixin();
            string postStr = "";            
            if (Request.HttpMethod.ToLower() == "post")
            {
                Stream s = System.Web.HttpContext.Current.Request.InputStream;
                byte[] b = new byte[s.Length];
                s.Read(b, 0, (int)s.Length);
                postStr = Encoding.UTF8.GetString(b);
                if (!string.IsNullOrEmpty(postStr))
                {
                    wx.responseMsg(postStr);
                }
            }
            else
            {
                wx.Auth();
            }
        } 
    }
}