﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Web.Security;
using System.IO;
using System.Xml;
using System.Text;
using System.Text.RegularExpressions;
using System.Configuration;

namespace WechatWebApp
{
    public class Weixin
    {
    
        private Dictionary<string, string> editable = new Dictionary<string, string>();
        public Weixin()
        {
            setEditableValue();
            if (this.editable == null || this.editable.Count==0)
            {
                setDefauleeditable();
            }     
        }
        public void Auth()
        {
            string echoStr = System.Web.HttpContext.Current.Request.QueryString["echoStr"];

            if (CheckSignature())
            {
                if (!string.IsNullOrEmpty(echoStr))
                {
                    System.Web.HttpContext.Current.Response.Write(echoStr);
                    System.Web.HttpContext.Current.Response.End();
                }
            }
        }
        private bool CheckSignature()
        {

            string Token = "weixin";
            string signature = System.Web.HttpContext.Current.Request.QueryString["signature"];
            string timestamp = System.Web.HttpContext.Current.Request.QueryString["timestamp"];

            string nonce = System.Web.HttpContext.Current.Request.QueryString["nonce"];

            string[] ArrTmp = { Token, timestamp, nonce };

            Array.Sort(ArrTmp);

            string tmpStr = string.Join("", ArrTmp);

            tmpStr = FormsAuthentication.HashPasswordForStoringInConfigFile(tmpStr, "SHA1");

            tmpStr = tmpStr.ToLower();

            if (tmpStr == signature)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public void responseMsg(string postStr)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(postStr);
                XmlElement rootElement = doc.DocumentElement;
                String keyword = "";
                String FromUserName = "";
                String ToUserName = "";
                String messageType = "";
                String eventAction = "";
                String eventKey = "";
                if (rootElement.SelectSingleNode("FromUserName") != null)
                {
                    FromUserName = rootElement.SelectSingleNode("FromUserName").InnerText;
                }
                if (rootElement.SelectSingleNode("ToUserName") != null)
                {
                    ToUserName = rootElement.SelectSingleNode("ToUserName").InnerText;
                }
                if (rootElement.SelectSingleNode("MsgType") != null)
                {
                    messageType = rootElement.SelectSingleNode("MsgType").InnerText;
                }
                if (rootElement.SelectSingleNode("Event") != null)
                {
                    eventAction = rootElement.SelectSingleNode("Event").InnerText;
                }
                if (rootElement.SelectSingleNode("EventKey") != null)
                {
                    eventKey = rootElement.SelectSingleNode("EventKey").InnerText;
                }
                if (rootElement.SelectSingleNode("Content") != null)
                {
                    keyword = rootElement.SelectSingleNode("Content").InnerText;
                }
                String createtime = ((int)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds).ToString();

                String textTpl = "<xml>"
                                + "<ToUserName><![CDATA[{0}]]></ToUserName>"
                                + "<FromUserName><![CDATA[{1}]]></FromUserName>"
                                + "<CreateTime>{2}</CreateTime>"
                                + "<MsgType><![CDATA[{3}]]></MsgType>"
                                + "<Content><![CDATA[{4}]]></Content>"
                                + "<FuncFlag>0</FuncFlag>"
                                + "</xml>";
                if (!string.IsNullOrEmpty(keyword))
                {
                    int number;
                    //log("Check if it is number!!");
                    bool result = Int32.TryParse(keyword, out number);
                    if (result)
                    {
                        log("Query Keyword: number Actual Query:" + keyword);
                        String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/quote_page_c.asp?WidCoID=" + number.ToString();
                        CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
                        String temple = browser.GenerateTemple(url, number.ToString(),"2.1b",editable);
                        System.Web.HttpContext.Current.Response.Write(temple);
                    }
                    else if (Int32.TryParse(keyword.Substring(0, keyword.Length - 1), out number) && findTheMatchValue(keyword, @"[^0-9]+[a-z0-9]*", 0) == "G" || findTheMatchValue(keyword, @"[^0-9]+[a-z0-9]*", 0) == "g")
                     {
                        // log("Query Keyword: Number+G Actual Query:" + keyword);
                         keyword = assigeFixedlength(keyword.Substring(0, keyword.Length - 1),"0",5,0);
                         String url = "http://www.hkexnews.hk/listedco/listconews/advancedsearch/search_active_main_c.aspx";
                         //String url = "http://www.hkexnews.hk/listedco/listconews/advancedsearch/search_active_main.aspx";
                         CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
                         String temple = browser.GenerateTemple(url, keyword,"2.2b",editable);
                         System.Web.HttpContext.Current.Response.Write(temple);
                     }
                    else if (keyword == "成交")
                    {
                        log("Query Keyword: 成交 Actual Query" + keyword);
                        V1001_deal(textTpl, FromUserName, ToUserName, createtime);
                    }
                    else if (keyword == "十大")
                    {
                        log("Query Keyword: 十大 Actual Query" + keyword);
                        V1002_actstock(textTpl, FromUserName, ToUserName, createtime);
                       
                    }
                    else if (keyword == "恆指" || keyword == "恒指")
                    {
                        log("Query Keyword: 恆指 Actual Query" + keyword);
                   
                        V1003_index(FromUserName,ToUserName,createtime);
                    }
                    else if (keyword == "行情")
                    {
                        log("Query Keyword: 行情 Actual Query" + keyword);
                        V2001_stockinfo(textTpl, FromUserName, ToUserName, createtime);
                    }
                    else if (keyword == "公告")
                    {
                        log("Query Keyword: 公告 Actual Query" + keyword);
                        V2002_companyinfo(textTpl, FromUserName, ToUserName, createtime);
                        

                    }else if(keyword =="小加"){
                        log("Query Keyword: 小加 Actual Query" + keyword);
                        V1002_BLOG(FromUserName,ToUserName,createtime);
                    }else if (keyword == "?" || keyword=="？")
                    {
                        log("Query Keyword: ? Actual Query" + keyword);
                        string msg = this.editable["Help"];
                        string msgType = "text";
                        String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
                        System.Web.HttpContext.Current.Response.Write(myStr);
                   }
                    else
                    {
                        log("Query Keyword: "+keyword);
                        string output = HttpUtility.UrlEncode(keyword, Encoding.GetEncoding("GB2312"));
                        String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/excompany_page_c.asp?QueryString=" + output;
                        CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
                        String temple = browser.GenerateTemple(url, keyword,"2.1c",editable);
                        System.Web.HttpContext.Current.Response.Write(temple);
                    }
                }// end keyword is not null
                else
                {
                    if (messageType == "event")
                    {
                        if (eventKey == "V1001_deal")
                        {
                            V1001_deal(textTpl, FromUserName, ToUserName, createtime);

                        }
                        else if (eventKey == "V1002_actstock")
                        {
                           
                            V1002_actstock(textTpl,FromUserName,ToUserName,createtime);

                        }
                        else if (eventKey == "V1003_index")
                        {
                            V1003_index(FromUserName, ToUserName, createtime);

                        }
                        else if (eventKey == "V2001_stockinfo")
                        {
                            V2001_stockinfo(textTpl,FromUserName,ToUserName,createtime);
                        }
                        else if (eventKey == "V2002_companyinfo")
                        {
                           
                            V2002_companyinfo(textTpl, FromUserName, ToUserName, createtime);
                        }
                        else if(eventKey=="V1002_BLOG"){
                            V1002_BLOG(FromUserName,ToUserName,createtime);
                        }
                        else
                        {
                            if (eventAction == "subscribe")
                            {
                                //setMenu();
                                subscribe(textTpl, FromUserName, ToUserName, createtime);
                            }
                            else
                            {
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //log("Error Occur:" + ex.Message);
            }
        }

        private void V1001_deal(String textTpl,String FromUserName,String ToUserName,String createtime)
        {
            string url = "http://www.hkex.com.hk/chi/csm/script/tc_ChinaConnectTurnover.js?Token=70556";
            WebClient wc = new WebClient();
            String htmlcode = wc.DownloadString(url);
            String msg = "";
            String turnover_date = findTheMatchValue(htmlcode, @"turnover_date = ""(.+?)""", 1);
            String northbound_turnover = findTheMatchValue(htmlcode, @"northbound_turnover = ""\s*(.+?)\s*"";", 1);
            String northbound_buy = findTheMatchValue(htmlcode, @"northbound_buy = ""\s*(.+?)\s*"";", 1);
            String northbound_sell = findTheMatchValue(htmlcode, @"northbound_sell = ""\s*(.+?)\s*"";", 1);
            String southbound_turnover = findTheMatchValue(htmlcode, @"southbound_turnover = ""\s*(.+?)\s*"";", 1);
            String southbound_buy = findTheMatchValue(htmlcode, @"southbound_buy = ""\s*(.+?)\s*"";", 1);
            String southbound_sell = findTheMatchValue(htmlcode, @"southbound_sell = ""\s*(.+?)\s*"";", 1);        
            url = "http://www.hkex.com.hk/eng/csm/script/en_QuotaUsage.js?Token=53343";
            htmlcode = wc.DownloadString(url);
            String dailyDate = findTheMatchValue(htmlcode, @"<b>(\b\d{1,2}/\d{1,2}/\d{1,4}\b)</b>", 1);
            String openClosebalanceText = "";
            String openClosekeyword = "";
            if (findTheMatchValue(htmlcode, @"Closing Balance", 0) != "")
            {
                openClosebalanceText = "总额度收市余额 ";
                openClosekeyword="Closing Balance";
            }
            else
            {
                openClosebalanceText = "总额度开市余额 ";
                openClosekeyword = "Opening Balance";
            }
            String openClosingBalance = findTheMatchValue(htmlcode, @"<Font class=font1>"+openClosekeyword+@"</font></td><TD align=right><Font class=font1>([a-zA-Z0-9\, ]{1,})</font>", 1);
            String daily_quota = findTheMatchValue(htmlcode, @"<Font class=font1>(\([a-zA-Z]{3}\))</font>", 1);
            String quota_amount = findTheMatchValue(htmlcode, @"<Font class=font1>Quota Amount</font></td><TD align=right><Font class=font1>([a-zA-Z0-9\, ]{1,})</font>", 1);
            String[] balance = findTheMatchValues(htmlcode, @"<Font class=font1>Balance \(as at ([0-9/:]{1,5})\)</font></td><TD align=right><Font class=font1>([a-zA-Z0-9, ]{1,})</font>", new int[] { 1, 2 });
            String balance_of_quota = findTheMatchValue(htmlcode, @"<Font class=font1>Balance as % of Quota Amount</font></td><TD align=right><Font class=font1>([0-9%]{1,})</font>", 1);
            if (turnover_date!=string.Empty){
                msg = turnover_date + "\n" ;
            }
            if (northbound_turnover != string.Empty)
            {
                msg+="沪股通成交额 " + northbound_turnover + "\n";
            }
            if (northbound_buy.Trim() != string.Empty)
            {
                msg+="买入 " + northbound_buy + "\n";
            }
            if (northbound_sell != string.Empty)
            {
                msg+="卖出 " + northbound_sell + "\n\n" ;
            }
            if (southbound_turnover != string.Empty)
            {
                msg += "港股通成交额 " + southbound_turnover + "\n";
            }
            if (southbound_buy != string.Empty)
            {
                msg += "买入 " + southbound_buy + "\n";
            }
            if (southbound_sell != string.Empty)
            {
                msg += "卖出 " + southbound_sell + "\n\n";
            }
            if (dailyDate != string.Empty)
            {
                msg += dailyDate + "\n";
            }
                msg += "沪股通额度资料\n";
            if (openClosingBalance != string.Empty)
            {
                msg += openClosebalanceText + openClosingBalance + "\n";
            }
            if (daily_quota != string.Empty)
            {
                msg += "每日额度 " + daily_quota + quota_amount + "\n";
            }
            if (balance[0] != string.Empty && balance[1] != string.Empty)
            {
                msg += "余额(於 " + balance[0] + ") " + balance[1] + "\n";
            }
            if (balance_of_quota != string.Empty)
            {
                msg += "余额占额度百分比 " + balance_of_quota + "\n\n";
            }
                msg+="港股通额度资料\n" ;
                msg += editable["1.1"];
            string msgType = "text";
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
            System.Web.HttpContext.Current.Response.Write(myStr);
        }

        private void V1002_actstock(String textTpl, String FromUserName,String ToUserName,String createtime)
        {
            CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
            //String temple = browser.GenerateTemple("http://www.hkex.com.hk/chi/csm/dailystat/d", "V1002_actstock");
            String temple = browser.GenerateTemple("http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/dailystat/d", "", "1.2", editable);

            System.Web.HttpContext.Current.Response.Write(temple);
        }

        private void V1003_index(String FromUserName, String ToUserName, String createtime)
        {
            String newsTpl = "<xml>" +
                                            "<ToUserName><![CDATA[{0}]]></ToUserName>" +
                                            "<FromUserName><![CDATA[{1}]]></FromUserName>" +
                                            "<CreateTime>{2}</CreateTime>" +
                                            "<MsgType><![CDATA[{3}]]></MsgType>" +
                                            "<ArticleCount>2</ArticleCount>" +
                                            "<Articles>{4}</Articles>" +
                                            "</xml>";
            String url = "http://sc.hkex.com.hk/TuniS/www.hkex.com.hk/chi/index_c.htm";
            WebClient wc = new WebClient();
            String htmlcode = wc.DownloadString(url);
            String msg = "";
            String date = findTheMatchValue(htmlcode, @"hkex_hsi_date =  ""(\b\d{1,2}/\d{1,2}/\d{1,4}\b)"";", 1);
            String imageurl = "http://www.hkex.com.hk" + findTheMatchValue(htmlcode, @"hkex_hsi_chart = ""(.*)"";", 1);
            String marketindex = findTheMatchValue(htmlcode, @"hkex_hsi_index = ""([-+]?[0-9]*\.?[0-9]*)"";", 1);
            String changeMarketIndex = findTheMatchValue(htmlcode, @"hkex_hsi_change = ""([-+]?[0-9]*\.?[0-9]*)"";", 1);
            String changeMarketIndexPer = findTheMatchValue(htmlcode, @"hkex_hsi_change_percentage = ""(\S+)"";", 1);
            String link = "http://sc.hkex.com.hk/TuniS/m.hkex.com.hk/sc/index.htm";
            String newsItem = "";

            for (int i = 0; i < 2; i++)
            {
                if (i == 0)
                {
                    newsItem += "<item>";

                    if (changeMarketIndex == String.Empty && Encoding.UTF8.GetString(Encoding.Default.GetBytes(changeMarketIndexPer)).Substring(0, 2) == "上日")
                    {
                        newsItem += "<Title><![CDATA[" + date + "  " + marketindex + "  (上日收市)]]></Title>";
                    }
                    else if (changeMarketIndex != String.Empty && changeMarketIndexPer != String.Empty)
                    {
                        newsItem += "<Title><![CDATA[" + date + "  " + marketindex + "  " + changeMarketIndex + "(" + changeMarketIndexPer + "%)]]></Title>";
                    }
                    else
                    {
                        newsItem += "<Title><![CDATA[" + date + "  " + marketindex + "]]></Title>";

                    }
                    newsItem+="<Description><![CDATA["+this.editable["1.3"]+"]]></Description>" +
                   "<PicUrl><![CDATA[" + imageurl + "]]></PicUrl>" +
                   "<Url><![CDATA[" + link + "]]></Url>" +
                   "</item>";
                }
                else
                {
                    newsItem += "<item>" +
                  "<Title><![CDATA[" + this.editable["1.3"] + "]]></Title>" +
                  "<Description><![CDATA[Description]]></Description>" +
                  "<PicUrl><![CDATA[]]></PicUrl>" +
                  "<Url><![CDATA[" + link + "]]></Url>" +
                  "</item>";
                }
            }
            String msgType = "news";
            String myStr = String.Format(newsTpl, FromUserName, ToUserName, createtime, msgType, newsItem);
            System.Web.HttpContext.Current.Response.Write(myStr);
        }


        private void V2001_stockinfo(String textTpl, String FromUserName, String ToUserName, String createtime)
        {
            string msg = editable["2.1a"];
            string msgType = "text";
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
            System.Web.HttpContext.Current.Response.Write(myStr);
        }

        private void V2002_companyinfo(String textTpl,String FromUserName,String ToUserName,String createtime)
        {
            string msg = editable["2.2a"];
            string msgType = "text";
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
            System.Web.HttpContext.Current.Response.Write(myStr);

        }
        private void V1002_BLOG(String FromUserName,String  ToUserName, String createtime)
        {
            String newsTpl = "<xml>" +
                                            "<ToUserName><![CDATA[{0}]]></ToUserName>" +
                                            "<FromUserName><![CDATA[{1}]]></FromUserName>" +
                                            "<CreateTime>{2}</CreateTime>" +
                                            "<MsgType><![CDATA[news]]></MsgType>" +
                                            "<ArticleCount>5</ArticleCount>" +
                                            "<Articles>{3}</Articles>" +
                                            "</xml>";
            CustomBrowser browser = new CustomBrowser(newsTpl, FromUserName, ToUserName, createtime);
            String temple = browser.GenerateTemple("http://sc.hkex.com.hk/TuniS/www.hkex.com.hk/chi/newsconsul/blog/blog_c.htm", "", "3.2", editable);

            System.Web.HttpContext.Current.Response.Write(temple);
        }

        private void subscribe(String textTpl,String FromUserName,String ToUserName,String createtime)
        {
            string msgType = "text";
            string contentStr = this.editable["Subscribe"];
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, contentStr);
            System.Web.HttpContext.Current.Response.Write(myStr);
        }

        public void log(String message)
        {
            string mydocpath = "C:/debug/";
            string filename = String.Format("{0:yyyyMMdd}", DateTime.Today) + ".txt";
            StringBuilder sb = new StringBuilder();
            String path = mydocpath + filename;
            // Enumerate the files in the My Documents path, filtering for text files only. 

            if (!File.Exists(path))
            {

                using (StreamWriter sw = File.CreateText(path))
                {
                    sb.AppendLine(DateTime.Today.ToString() + " " + message);
                    sb.AppendLine("= = = = = =");
                }
            }
            else
            {

                using (StreamReader sr = new StreamReader(path))
                {
                    sb.AppendLine(DateTime.Today.ToString() + " " + message);
                    sb.AppendLine("= = = = = =");
                    sb.Append(sr.ReadToEnd());
                    sb.AppendLine();
                }

                using (StreamWriter outfile = new StreamWriter(path))
                {
                    outfile.Write(sb.ToString());
                }
            }

        }

        public string assigeFixedlength(String word, string prefix, int Totallength, int beforeAfter)
        {
            String prefixstr = "";
            int difflength = Totallength - word.Length;
            if (difflength <= 0)
            {
                return word.Substring(0, Totallength);
            }
            for (int i = 0; i < difflength; i++)
            {
                prefixstr += prefix;
            }

            if (beforeAfter > 0)//after word
            {
                return word + prefixstr;
            }
            else//before word
            {
                return prefixstr + word;
            }
        }


        public string findTheMatchValue(string htmlCode, string regexStr, int index)
        {

            //Match m = Regex.Match(htmlcode, @"<title>\s*(.+?)\s*</title>");
            Match m = Regex.Match(htmlCode, regexStr);
            if (m.Success)
            {
                return m.Groups[index].Value;
            }
            else
            {
                return "";
            }

        }

        public string[] findTheMatchValues(string htmlCode, string regexStr, int[] index)
        {
            Match m = Regex.Match(htmlCode, regexStr);
            string[] matchedValue = new String[index.Length];
            for (int i = 0; i < index.Length; i++)
            {

                if (m.Success)
                {
                    matchedValue[i] = m.Groups[index[i]].Value;
                }
                else
                {
                    matchedValue[i] = "";
                }

            }
            return matchedValue;
        }

        public void setDefauleeditable()
        {
            this.editable.Add("1.1", "请<a href=\"http://www.sse.com.cn/marketservices/hkexsc/home/\">按此</a>查看港股交易通额度资料。");
            this.editable.Add("1.2", "以上为前一個交易日的交易资料。如您需要了解详细成交资料，请<a href=\"http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/dailystat/\">按此</a>");
            this.editable.Add("1.3", "恒生指数属恒生指数有限公司拥有并由其提供。恒生指数經四舍五入如需查看其它指数，请<a href=\"http://sc.hkex.com.hk/TuniS/m.hkex.com.hk/sc/index.htm\">按此</a>。");
            this.editable.Add("2.1a","证券行情查询：请直接回复“证券代号”。如需查询代号，请回复“上市公司名称”。");
            this.editable.Add("2.1b","以上资料最少延时15分钟。\n成交资料於开市前时段的对盘时段结束十五分钟后提供。");
            this.editable.Add("2.1c","证券查询：请直接回复“证券代号”。");
            this.editable.Add("2.2a","上市公司公告查询：请直接回复“证券代号”+”G”。例子：“1G”。如需查询代号，请回复“上市公司名称”。");
            this.editable.Add("2.2b","如您需要更多资料，请<a href=\"http://sc.hkexnews.hk/TuniS/www.hkexnews.hk/index_c.htm\">按此</a>。");
            this.editable.Add("Subscribe", "你好，欢迎关注沪港通，我们将与您分享沪港通有关活动的最新消息。");
            this.editable.Add("Default","感谢你的查询!\n请输入股票代码(如:5 或 0005) 以查询其相关信息。");
            this.editable.Add("Help", "您好，请回复以下指令选择服务\n" +
                                           "[成交] 沪港通成交及额度\n" +
                                           "[十大] 十大沪港通成交证券\n" +
                                           "[恒指] 恒生指数\n" +
                                           "[行情] 证券行情查询\n" +
                                           "[公告] 上市公司公告\n" +
                                           "[小加] 小加网志\n");
           
        }

        public void setEditableValue()
        {
            String url = "http://www.hkex.com.hk/chi/newsconsul/app/editable_c.htm";
            CustomBrowser browser = new CustomBrowser(url);
            this.editable = browser.updateEditable(); 
        }
        private void showAllEditable()
        {
             foreach (KeyValuePair<string, string> item in this.editable)
            {
                System.Web.HttpContext.Current.Response.Write("itemkey:"+item.Key+",itemValue:"+ item.Value+"\n");
            }
        }
    }
}