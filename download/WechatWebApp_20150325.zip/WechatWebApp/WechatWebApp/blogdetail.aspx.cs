﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WechatWebApp
{
    public partial class blogdetail : System.Web.UI.Page
    {
        public String articel {get;set;}
        protected void Page_Load(object sender, EventArgs e)
        {
           

            String detailpage = "";

            if (Request.HttpMethod.ToLower() == "get" && System.Web.HttpContext.Current.Request.QueryString["detailpage"] != null)
            {
                detailpage = System.Web.HttpContext.Current.Request.QueryString["detailpage"];
            }
            if (detailpage != "")
            {
                String url = "http://sc.hkex.com.hk/TuniS/www.hkex.com.hk/chi/newsconsul/blog/" + detailpage;


                CustomBrowser broswer = new CustomBrowser(url);

                String blogHtml = broswer.getHiddenPageBySting("blog");

                articel = blogHtml;
            }
        }
    }
}