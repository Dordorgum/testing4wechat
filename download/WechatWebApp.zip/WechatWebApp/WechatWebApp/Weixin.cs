﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Web.Security;
using System.IO;
using System.Xml;
using System.Text;
using System.Text.RegularExpressions;

namespace WechatWebApp
{
    public class Weixin
    {

        //wxdef363a5d71f854f 
        //b5a9680c89589d34a1b162726a3cd0b6
        //NS054wsv9C9vjXLCkzOtC1ImLR9yTErR_vYdVyy_QQR_4gTy-JjT1iCirPPnAHdD4jx6-Hj6aKaOrH1FQ55YAJ3rPlzwrCPrVzFU7hLzoVw

        //for actual id wx6a6eaf0c4456af06
        //secret  9fb1078ca64247ffc09b74cd011077a1

        private string weChatAppID = "wxdef363a5d71f854f";
        private string weChatAppSecret = "b5a9680c89589d34a1b162726a3cd0b6";
        //public string weChatAccessToken;
        //private string menuResult;

        private Dictionary<string, string> editable = new Dictionary<string, string>();

        //public String echoStrr;

        public Weixin()
        {
            setEditableValue();
            /*if(this.editable.Count==0){
                setDefauleeditable();
            }*/
           // showAllEditable();
           // setDefauleeditable();
            
        }

        public string getWeChatAccessToken()
        {
            string url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + this.weChatAppID + "&secret=" + this.weChatAppSecret;
            WebClient wc = new WebClient();
            //   var json = (JObject)JsonConvert.DeserializeObject(wc.DownloadString(url));
            //  var access_token = json["access_token"].ToString();
            return "";

        }


        public void Auth()
        {

            string echoStr = System.Web.HttpContext.Current.Request.QueryString["echoStr"];

            if (CheckSignature())
            {

                if (!string.IsNullOrEmpty(echoStr))
                {


                    System.Web.HttpContext.Current.Response.Write(echoStr);

                    System.Web.HttpContext.Current.Response.End();



                }

            }


            // return menuResult;
        }




        private bool CheckSignature()
        {

            string Token = "weixin";
            string signature = System.Web.HttpContext.Current.Request.QueryString["signature"];
            // menuResult = signature;
            string timestamp = System.Web.HttpContext.Current.Request.QueryString["timestamp"];

            string nonce = System.Web.HttpContext.Current.Request.QueryString["nonce"];

            string[] ArrTmp = { Token, timestamp, nonce };

            Array.Sort(ArrTmp);

            string tmpStr = string.Join("", ArrTmp);

            tmpStr = FormsAuthentication.HashPasswordForStoringInConfigFile(tmpStr, "SHA1");

            tmpStr = tmpStr.ToLower();

            if (tmpStr == signature)
            {
                return true;

            }

            else
            {
                //  log("signature don't equal to SHA1(tmpStr)!!");
                return false;

            }

        }


        public void responseMsg(string postStr)
        {
            String deubgStr = "";

            try
            {

                XmlDocument doc = new XmlDocument();

                doc.LoadXml(postStr);

                XmlElement rootElement = doc.DocumentElement;


                String keyword = "";
                String FromUserName = "";
                String ToUserName = "";
                String messageType = "";
                String eventAction = "";
                String eventKey = "";
                // deubgStr += postStr+"  ";
                // RequestXML requestXML = new RequestXML();

                if (rootElement.SelectSingleNode("FromUserName") != null)
                {
                    FromUserName = rootElement.SelectSingleNode("FromUserName").InnerText;
                }
                if (rootElement.SelectSingleNode("ToUserName") != null)
                {
                    ToUserName = rootElement.SelectSingleNode("ToUserName").InnerText;
                }
                if (rootElement.SelectSingleNode("MsgType") != null)
                {
                    messageType = rootElement.SelectSingleNode("MsgType").InnerText;
                }
                if (rootElement.SelectSingleNode("Event") != null)
                {
                    eventAction = rootElement.SelectSingleNode("Event").InnerText;
                }
                if (rootElement.SelectSingleNode("EventKey") != null)
                {
                    eventKey = rootElement.SelectSingleNode("EventKey").InnerText;
                }


                if (rootElement.SelectSingleNode("Content") != null)
                {
                    keyword = rootElement.SelectSingleNode("Content").InnerText;
                }


                // String CreateTime = rootElement.SelectSingleNode("CreateTime").InnerText;
                //String createtime = DateTime.UtcNow.ToString();
                String createtime = ((int)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds).ToString();

                String textTpl = "<xml>"
                                + "<ToUserName><![CDATA[{0}]]></ToUserName>"
                                + "<FromUserName><![CDATA[{1}]]></FromUserName>"
                                + "<CreateTime>{2}</CreateTime>"
                                + "<MsgType><![CDATA[{3}]]></MsgType>"
                                + "<Content><![CDATA[{4}]]></Content>"
                                + "<FuncFlag>0</FuncFlag>"
                                + "</xml>";


                if (!string.IsNullOrEmpty(keyword))
                {
                    int number;
                    
                    bool result = Int32.TryParse(keyword, out number);
                    log(result.ToString());
                    if (result)
                    {
                        String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/quote_page_c.asp?WidCoID=" + number.ToString();
                        CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
                        String temple = browser.GenerateTemple(url, number.ToString(),"2.1b",editable);
                        System.Web.HttpContext.Current.Response.Write(temple);

                    }
                    else if (Int32.TryParse(keyword.Substring(0, keyword.Length - 1), out number) && findTheMatchValue(keyword, @"[^0-9]+[a-z0-9]*", 0) == "G" || findTheMatchValue(keyword, @"[^0-9]+[a-z0-9]*", 0) == "g")
                     {

                         keyword = assigeFixedlength(keyword.Substring(0, keyword.Length - 1),"0",5,0);
                         //string output = HttpUtility.UrlEncode(keyword, Encoding.GetEncoding("GB2312"));
                         String url = "http://www.hkexnews.hk/listedco/listconews/advancedsearch/search_active_main_c.aspx";
                         //String url = "http://www.hkexnews.hk/listedco/listconews/advancedsearch/search_active_main.aspx";
                         CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
                         String temple = browser.GenerateTemple(url, keyword,"2.2b",editable);
                         System.Web.HttpContext.Current.Response.Write(temple);
                     }
                    else if (keyword == "成交")
                    {
                        V1001_deal(textTpl, FromUserName, ToUserName, createtime);
                    }
                    else if (keyword == "十大")
                    {
                        V1002_actstock(textTpl, FromUserName, ToUserName, createtime);
                       
                    }
                    else if (keyword == "恆指")
                    {
                        V1003_index(FromUserName,ToUserName,createtime);
                    }
                    else if (keyword == "行情")
                    {
                        V2001_stockinfo(textTpl, FromUserName, ToUserName, createtime);
                    }
                    else if (keyword == "公告")
                    {
                        V2002_companyinfo(textTpl, FromUserName, ToUserName, createtime);
                        

                    }else if(keyword =="小加"){
                        V1002_BLOG(FromUserName,ToUserName,createtime);
                    }else if (keyword == "?")
                    {
                        string msg = this.editable["Help"];
                        string msgType = "text";
                        String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
                        System.Web.HttpContext.Current.Response.Write(myStr);
                   }
                    else
                    {
                        string output = HttpUtility.UrlEncode(keyword, Encoding.GetEncoding("GB2312"));
                        String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/excompany_page_c.asp?QueryString=" + output;
                        CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
                        String temple = browser.GenerateTemple(url, keyword,"2.1c",editable);
                        System.Web.HttpContext.Current.Response.Write(temple);
                    }
                    //
                }// end keyword is not null
                else
                {
                    if (messageType == "event")
                    {
                        if (eventKey == "V1001_deal")
                        {
                            V1001_deal(textTpl, FromUserName, ToUserName, createtime);

                        }
                        else if (eventKey == "V1002_actstock")
                        {
                           
                            V1002_actstock(textTpl,FromUserName,ToUserName,createtime);

                        }
                        else if (eventKey == "V1003_index")
                        {
                            V1003_index(FromUserName, ToUserName, createtime);

                        }
                        else if (eventKey == "V2001_stockinfo")
                        {
                            V2001_stockinfo(textTpl,FromUserName,ToUserName,createtime);
                        }
                        else if (eventKey == "V2002_companyinfo")
                        {
                           
                            V2002_companyinfo(textTpl, FromUserName, ToUserName, createtime);
                        }
                        else if(eventKey=="V1002_BLOG"){
                            V1002_BLOG(FromUserName,ToUserName,createtime);
                        }
                        else
                        {
                            if (eventAction == "subscribe")
                            {
                                //setMenu();
                                subscribe(textTpl, FromUserName, ToUserName, createtime);
                            }
                            else
                            {
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                deubgStr += ex.Message;
                log("Error Occur:" + deubgStr);
            }
        }

        private void V1001_deal(String textTpl,String FromUserName,String ToUserName,String createtime)
        {
            string url = "http://www.hkex.com.hk/chi/csm/script/tc_ChinaConnectTurnover.js?Token=70556";
            WebClient wc = new WebClient();
            String htmlcode = wc.DownloadString(url);
            String msg = "";
            String turnover_date = findTheMatchValue(htmlcode, @"turnover_date = ""(.+?)""", 1);
            String northbound_turnover = findTheMatchValue(htmlcode, @"northbound_turnover = ""\s*(.+?)\s*"";", 1);
            String northbound_buy = findTheMatchValue(htmlcode, @"northbound_buy = ""\s*(.+?)\s*"";", 1);
            String northbound_sell = findTheMatchValue(htmlcode, @"northbound_sell = ""\s*(.+?)\s*"";", 1);
            String southbound_turnover = findTheMatchValue(htmlcode, @"southbound_turnover = ""\s*(.+?)\s*"";", 1);
            String southbound_buy = findTheMatchValue(htmlcode, @"southbound_buy = ""\s*(.+?)\s*"";", 1);
            String southbound_sell = findTheMatchValue(htmlcode, @"southbound_sell = ""\s*(.+?)\s*"";", 1);



            // System.Web.HttpContext.Current.Response.Write(turnover_date + " " + northbound_turnover + " " + southbound_turnover);

            url = "http://www.hkex.com.hk/eng/csm/script/en_QuotaUsage.js?Token=53343";
            htmlcode = wc.DownloadString(url);
            String dailyDate = findTheMatchValue(htmlcode, @"<b>(\b\d{1,2}/\d{1,2}/\d{1,4}\b)</b>", 1);
            String closingBalance = findTheMatchValue(htmlcode, @"<Font class=font1>Closing Balance</font></td><TD align=right><Font class=font1>([a-zA-Z0-9\, ]{1,})</font>", 1);
            String daily_quota = findTheMatchValue(htmlcode, @"<Font class=font1>(\([a-zA-Z]{3}\))</font>", 1);
            String quota_amount = findTheMatchValue(htmlcode, @"<Font class=font1>Quota Amount</font></td><TD align=right><Font class=font1>([a-zA-Z0-9\, ]{1,})</font>", 1);
            String[] balance = findTheMatchValues(htmlcode, @"<Font class=font1>Balance \(as at ([0-9/:]{1,5})\)</font></td><TD align=right><Font class=font1>([a-zA-Z0-9, ]{1,})</font>", new int[] { 1, 2 });
            String balance_of_quota = findTheMatchValue(htmlcode, @"<Font class=font1>Balance as % of Quota Amount</font></td><TD align=right><Font class=font1>([0-9%]{1,})</font>", 1);
            string link = "http://www.sse.com.cn/marketservices/hkexsc/home/";
            msg = turnover_date + "\n" +
                "沪股通成交额 " + northbound_turnover + "\n" +
                "买入 " + northbound_buy + "\n" +
                "卖出 " + northbound_sell + "\n\n" +
                "港股通成交额 " + southbound_turnover + "\n" +
                "买入 " + southbound_buy + "\n" +
                "卖出 " + southbound_sell + "\n\n" +
                dailyDate + "\n" +
                "沪股通额度资料\n" +
                "总额度开市余额 " + closingBalance + "\n" +
                "每日额度 " + daily_quota + quota_amount + "\n" +
                "余额(於 " + balance[0] + ") " + balance[1] + "\n" +
                "余额占额度百分比 " + balance_of_quota + "\n\n" +
                "港股通额度资料\n" +
                 editable["1.1"];//"请<a href=\"" + link + "\">按此</a>查看港股交易通额度资料。";
            /*
                "沪股通 " + northbound_turnover + "\n(买入及卖出)\n\n" + "港股通 " + southbound_turnover + "\n" + "(买入及卖出)\n-----------------------------\n" +
                "沪股交易通 (" + dailyDate + ")\n" + "每日额度 " + daily_quota + "\n" + "额度 " + quota_amount + "\n" + "余额(" + balance[0] + ")\t" + balance[1] + "\n余额占额度百分比 " + balance_of_quota + "\n-----------------------------\n" +
                "请<a href=\"" + link + "\">按此</a>查看港股交易通额度资料。";*/
            // System.Web.HttpContext.Current.Response.Write(" " + dailyDate + " " + daily_quota + " " + quota_amount + " " + balance[0] + " " + balance[1] + " " + balance_of_quota);

            string msgType = "text";
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
            System.Web.HttpContext.Current.Response.Write(myStr);
            // System.Web.HttpContext.Current.Response.End();
            // log(myStr);
        }

        private void V1002_actstock(String textTpl, String FromUserName,String ToUserName,String createtime)
        {
            CustomBrowser browser = new CustomBrowser(textTpl, FromUserName, ToUserName, createtime);
            //String temple = browser.GenerateTemple("http://www.hkex.com.hk/chi/csm/dailystat/d", "V1002_actstock");
            String temple = browser.GenerateTemple("http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/dailystat/d", "", "1.2", editable);

            System.Web.HttpContext.Current.Response.Write(temple);
        }

        private void V1003_index(String FromUserName, String ToUserName, String createtime)
        {
            String newsTpl = "<xml>" +
                                            "<ToUserName><![CDATA[{0}]]></ToUserName>" +
                                            "<FromUserName><![CDATA[{1}]]></FromUserName>" +
                                            "<CreateTime>{2}</CreateTime>" +
                                            "<MsgType><![CDATA[{3}]]></MsgType>" +
                                            "<ArticleCount>2</ArticleCount>" +
                                            "<Articles>{4}</Articles>" +
                                            "</xml>";
            //String url = "http://www.hkex.com.hk/eng/index.htm";

            String url = "http://sc.hkex.com.hk/TuniS/www.hkex.com.hk/chi/index_c.htm";
            WebClient wc = new WebClient();
            String htmlcode = wc.DownloadString(url);
            String msg = "";
            String date = findTheMatchValue(htmlcode, @"hkex_hsi_date =  ""(\b\d{1,2}/\d{1,2}/\d{1,4}\b)"";", 1);
            String imageurl = "http://www.hkex.com.hk" + findTheMatchValue(htmlcode, @"hkex_hsi_chart = ""(.*)"";", 1);
            //String marketindex = findTheMatchValue(htmlcode, @"hkex_hsi_index = ""([-+]?[0-9]*\.?[0-9]+.)"";", 1);
            //String changeMarketIndex = findTheMatchValue(htmlcode, @"hkex_hsi_change = ""([-+]?[0-9]*\.?[0-9]+.)"";", 1);
            //String changeMarketIndexPer = findTheMatchValue(htmlcode, @"hkex_hsi_change_percentage = ""([-+]?[0-9]*\.?[0-9]+.)"";", 1);
            String marketindex = findTheMatchValue(htmlcode, @"hkex_hsi_index = ""([-+]?[0-9]*\.?[0-9]*)"";", 1);
            String changeMarketIndex = findTheMatchValue(htmlcode, @"hkex_hsi_change = ""([-+]?[0-9]*\.?[0-9]*)"";", 1);
            String changeMarketIndexPer = findTheMatchValue(htmlcode, @"hkex_hsi_change_percentage = ""([-+]?[0-9]*\.?[0-9]*)"";", 1);
            String link = "http://sc.hkex.com.hk/TuniS/m.hkex.com.hk/sc/index.htm";
            String newsItem = "";

            for (int i = 0; i < 2; i++)
            {

                //恒生指数属恒生指数有限公司拥有并由其提供。恒生指数經四舍五入。
                if (i == 0)
                {
                    newsItem += "<item>" +
                   "<Title><![CDATA[" + date + "  " + marketindex + "  " + changeMarketIndex + "(" + changeMarketIndexPer + "%)]]></Title>" +
                   "<Description><![CDATA["+this.editable["1.3"]+"]]></Description>" +
                   "<PicUrl><![CDATA[" + imageurl + "]]></PicUrl>" +
                   "<Url><![CDATA[" + link + "]]></Url>" +
                   "</item>";
                }
                else
                {
                    newsItem += "<item>" +
                  "<Title><![CDATA[" + this.editable["1.3"] + "]]></Title>" +
                  "<Description><![CDATA[Description]]></Description>" +
                  "<PicUrl><![CDATA[]]></PicUrl>" +
                  "<Url><![CDATA[" + link + "]]></Url>" +
                  "</item>";
                }
                //$itemOne = $itemOne.sprintf($newsItem, $atitle[$i], "http://www.hkex.com.hk".$ahref[$i]);

            }

            /* msg = "恒生指数                    " + date + "\n";
             msg += marketindex + "              " + changeMarketIndex + "(" + changeMarketIndexPer + "%)\n";
             msg += "恒生指数属恒生指数有限公司拥有并由其提供。恒生指数經四舍五入如需查看其它指数，请<a href=\"" + link + "\">按此</a>";*/
            String msgType = "news";
            String myStr = String.Format(newsTpl, FromUserName, ToUserName, createtime, msgType, newsItem);
            // String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
            System.Web.HttpContext.Current.Response.Write(myStr);
            //log(myStr);
        }


        private void V2001_stockinfo(String textTpl, String FromUserName, String ToUserName, String createtime)
        {
            string msg = editable["2.1a"];//"证券行情查询：请直接回复“证券代号”。如需查询代号，请回复“上市公司名称”";
            string msgType = "text";
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
            System.Web.HttpContext.Current.Response.Write(myStr);
        }

        private void V2002_companyinfo(String textTpl,String FromUserName,String ToUserName,String createtime)
        {
            string msg = editable["2.2a"];//"上市公司公告查询：请直接回复“证券代号”+”G”。例子：“1G”。如需查询代号，请回复“上市公司名称”";
            string msgType = "text";
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, msg);
            System.Web.HttpContext.Current.Response.Write(myStr);

        }
        private void V1002_BLOG(String FromUserName,String  ToUserName, String createtime)
        {
            String newsTpl = "<xml>" +
                                            "<ToUserName><![CDATA[{0}]]></ToUserName>" +
                                            "<FromUserName><![CDATA[{1}]]></FromUserName>" +
                                            "<CreateTime>{2}</CreateTime>" +
                                            "<MsgType><![CDATA[news]]></MsgType>" +
                                            "<ArticleCount>5</ArticleCount>" +
                                            "<Articles>{3}</Articles>" +
                                            "</xml>";
            CustomBrowser browser = new CustomBrowser(newsTpl, FromUserName, ToUserName, createtime);
            String temple = browser.GenerateTemple("http://sc.hkex.com.hk/TuniS/www.hkex.com.hk/chi/newsconsul/blog/blog_c.htm", "", "3.2", editable);

            System.Web.HttpContext.Current.Response.Write(temple);
        }

        private void subscribe(String textTpl,String FromUserName,String ToUserName,String createtime)
        {
            string msgType = "text";
            string contentStr = this.editable["Subscribe"];//"你好，欢迎关注香港交易所脉搏，我们将与您分享香港交易所有关活动的最新消息。";
            String myStr = String.Format(textTpl, FromUserName, ToUserName, createtime, msgType, contentStr);
            System.Web.HttpContext.Current.Response.Write(myStr);
        }

        public void log(String message)
        {
            string mydocpath = "C:/debug/";
            string filename = String.Format("{0:yyyyMMdd}", DateTime.Today) + ".txt";
            StringBuilder sb = new StringBuilder();
            String path = mydocpath + filename;
            // Enumerate the files in the My Documents path, filtering for text files only. 

            if (!File.Exists(path))
            {

                using (StreamWriter sw = File.CreateText(path))
                {
                    sb.AppendLine(DateTime.Today.ToString() + " " + message);
                    sb.AppendLine("= = = = = =");
                }
            }
            else
            {

                using (StreamReader sr = new StreamReader(path))
                {
                    sb.AppendLine(DateTime.Today.ToString() + " " + message);
                    sb.AppendLine("= = = = = =");
                    sb.Append(sr.ReadToEnd());
                    sb.AppendLine();
                }

                using (StreamWriter outfile = new StreamWriter(path))
                {
                    outfile.Write(sb.ToString());
                }
            }

        }

        public string assigeFixedlength(String word, string prefix, int Totallength, int beforeAfter)
        {
            String prefixstr = "";
            int difflength = Totallength - word.Length;
            if (difflength <= 0)
            {
                return word.Substring(0, Totallength);
            }
            for (int i = 0; i < difflength; i++)
            {
                prefixstr += prefix;
            }

            if (beforeAfter > 0)//after word
            {
                return word + prefixstr;
            }
            else//before word
            {
                return prefixstr + word;
            }
        }


        public string findTheMatchValue(string htmlCode, string regexStr, int index)
        {

            //Match m = Regex.Match(htmlcode, @"<title>\s*(.+?)\s*</title>");
            Match m = Regex.Match(htmlCode, regexStr);
            if (m.Success)
            {
                return m.Groups[index].Value;
            }
            else
            {
                return "";
            }

        }


        public string[] findTheMatchValues(string htmlCode, string regexStr, int[] index)
        {
            Match m = Regex.Match(htmlCode, regexStr);
            string[] matchedValue = new String[index.Length];
            for (int i = 0; i < index.Length; i++)
            {

                if (m.Success)
                {
                    matchedValue[i] = m.Groups[index[i]].Value;
                }
                else
                {
                    matchedValue[i] = "";
                }

            }
            return matchedValue;
        }

        public void setDefauleeditable()
        {
            this.editable.Add("1.1", "请<a href=\"http://www.sse.com.cn/marketservices/hkexsc/home/\">按此</a>查看港股交易通额度资料。");
            this.editable.Add("1.2", "以上为前一個交易日的交易资料。如您需要了解详细成交资料，请<a href=\"http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/dailystat/d\">按此</a>");
            this.editable.Add("1.3", "恒生指数属恒生指数有限公司拥有并由其提供。恒生指数經四舍五入如需查看其它指数，请<a href=\"http://sc.hkex.com.hk/TuniS/m.hkex.com.hk/sc/index.htm\">按此</a>。");
            this.editable.Add("2.1a","证券行情查询：请直接回复“证券代号”。如需查询代号，请回复“上市公司名称”。");
            this.editable.Add("2.1b","以上资料最少延时15分钟。\n成交资料於开市前时段的对盘时段结束十五分钟后提供。");
            this.editable.Add("2.1c","证券查询：请直接回复“证券代号”。");
            this.editable.Add("2.2a","上市公司公告查询：请直接回复“证券代号”+”G”。例子：“1G”。如需查询代号，请回复“上市公司名称”。");
            this.editable.Add("2.2b","如您需要更多资料，请<a href=\"http://sc.hkexnews.hk/TuniS/www.hkexnews.hk/index_c.htm\">按此</a>。");
            this.editable.Add("Subscribe", "你好，欢迎关注沪港通，我们将与您分享沪港通有关活动的最新消息。");
            this.editable.Add("Default","感谢你的查询!\n请输入股票代码(如:5 或 0005) 以查询其相关信息。");
            this.editable.Add("Help", "您好，请回复以下指令选择服务\n" +
                                           "[成交] 沪港通成交及额度\n" +
                                           "[十大] 十大沪港通成交证券\n" +
                                           "[恒指] 恒生指数\n" +
                                           "[行情] 证券行情查询\n" +
                                           "[公告] 上市公司公告\n" +
                                           "[小加] 小加网志\n");
           
        }

        public void setEditableValue()
        {
            //String url = "http://testing4wechat.herokuapp.com/chi/newsconsul/app/editable_c.htm";
            String url = "http://220.246.12.161/testing2/editable.html";
            CustomBrowser browser = new CustomBrowser(url);
            this.editable = browser.updateEditable();
            
        }



        public void setMenu()
        {
            string jsonFormat = @"
                    {
                    button: [
                        {
                            type: 'view', 
                            name: '沪港通', 
                            url: 'http://www.hkex.com.hk/chi/csm/homepage.asp?LangCode=tc', 
                            sub_button: [ 
				                {
					                type:'click',
					                name:'沪港通成交',
					                key: 'V1001_deal',
					                sub_button:[ ]
				                },
				                {
					                type:'click',
					                name:'活跃股票',
					                key: 'V1002_actstock',
					                sub_button:[ ]
					
				                },
				                {
					                type:'click',
					                name:'恒生指数',
					                key:'V1003_index',
					                sub_button:[ ]
				                },
				                {
					                type:'view',
					                name:'沪港通资料',
					                url: 'https://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/chinaConnect.asp?LangCode=tc',
					                sub_button:[ ]
				                },
				                {
					                type:'view',
					                name:'港股通大讲堂',
					                url:'https://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/chinaConnect.asp?LangCode=tc',
					                sub_button:[ ]
				                }
			                ]
                        }, 
                        {
                            name: '证券查询', 
                            sub_button: [
				                {
					                type: 'click', 
                                    name: '证券行情', 
                                    key: 'V2001_stockinfo', 
                                    sub_button: [ ]
				                },
                                {
                                    type: 'click', 
                                    name: '上市公司公告', 
                                    key: 'V2002_companyinfo', 
                                    sub_button: [ ]
                                }, 
                                {
                                    type: 'view', 
                                    name: '港股通证券名单', 
                                    url: 'http://www.sse.com.cn/marketservices/hkexsc/disclo/eligible/',
                                    sub_button: [ ]
                                }
                            ]
                        },
		                {
                            name: '新闻资讯', 
                            sub_button: [ 
            	                {
                                    type: 'view', 
                                    name: '交易所公布 ', 
                                    url: 'https://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/chinaConnect.asp?LangCode=tc',
                                    sub_button: [ ]
                                }, 
                                {
                                    type: 'click', 
                                    name: '小加网志', 
                                    key: 'V1002_BLOG', 
                                    sub_button: [ ]
                                },
				                {
                                    type: 'view', 
                                    name: '交易日曆', 
                                    url: 'https://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/csm/chinaConnect.asp?LangCode=tc',
                                    sub_button: [ ]
                                }
                            ]
                        }
                    ]
                    }";
            /* string json = (string)JsonConvert.SerializeObject(jsonFormat);

             string post_url = string.Format("https://api.weixin.qq.com/cgi-bin/menu/create?access_token={0}", getWeChatAccessToken());
             var httpWebRequest = (HttpWebRequest)WebRequest.Create(post_url);
             httpWebRequest.ContentType = "text/json";
             httpWebRequest.Method = "POST";
         
             using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
             {
                 streamWriter.Write(json);
                 streamWriter.Flush();
                 streamWriter.Close();
             }

             var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
             using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
             {
                 var result = streamReader.ReadToEnd();
                 //debug
                 log(result.ToString());
             }
                 */

        }

        private void showAllEditable()
        {
             foreach (KeyValuePair<string, string> item in this.editable)
            {
                System.Web.HttpContext.Current.Response.Write("itemkey:"+item.Key+",itemValue:"+ item.Value+"\n");
                
            }

        }
        

    }

}