﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Web.Security;
using System.Net;
using System.Text.RegularExpressions;
using System.Xml;

namespace WechatWebApp
{
    public partial class _Default : System.Web.UI.Page
    {

        public string debug { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            Weixin wx = new Weixin();

            string postStr = "";


            //test();

            if (Request.HttpMethod.ToLower() == "post")
            {

                Stream s = System.Web.HttpContext.Current.Request.InputStream;

                byte[] b = new byte[s.Length];

                s.Read(b, 0, (int)s.Length);

                postStr = Encoding.UTF8.GetString(b);




                if (!string.IsNullOrEmpty(postStr))
                {

                    wx.responseMsg(postStr);

                }

            }

            else
            {
                wx.Auth();
            }


        }

        public void test()
        {
            //string userName = WebConfigurationManager.AppSettings["PFUserName"];
            //System.Web.HttpContext.Current.Response.Write(userName);
            /*String textTpl = "<xml>"
                                + "<ToUserName><![CDATA[{0}]]></ToUserName>"
                                + "<FromUserName><![CDATA[{1}]]></FromUserName>"
                                + "<CreateTime>{2}</CreateTime>"
                                + "<MsgType><![CDATA[{3}]]></MsgType>"
                                + "<Content><![CDATA[{4}]]></Content>"
                                + "<FuncFlag>0</FuncFlag>"
                                + "</xml>";

            int number;
            String keyword = "3";
            bool result = Int32.TryParse(keyword, out number);
            if (result)
            {
                String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/quote_page_c.asp?WidCoID=" + number.ToString();
                CustomBrowser browser = new CustomBrowser(textTpl, "", "", "");
                String temple = browser.GenerateTemple(url, number.ToString());
                System.Web.HttpContext.Current.Response.Write(temple);
            }*/
          /*
            Dictionary<String ,String > editable=new Dictionary<String ,String>();
            editable.Add("2.1b","test");
            String textTpl = "<xml>"
                               + "<ToUserName><![CDATA[{0}]]></ToUserName>"
                               + "<FromUserName><![CDATA[{1}]]></FromUserName>"
                               + "<CreateTime>{2}</CreateTime>"
                               + "<MsgType><![CDATA[{3}]]></MsgType>"
                               + "<Content><![CDATA[{4}]]></Content>"
                               + "<FuncFlag>0</FuncFlag>"
                               + "</xml>";
            int number = 2009;
            String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/quote_page_c.asp?WidCoID=" + number.ToString();
            CustomBrowser browser = new CustomBrowser(textTpl, "", "", "");
            String temple = browser.GenerateTemple(url, number.ToString(),"2.1b",editable);
            System.Web.HttpContext.Current.Response.Write(temple);
            */
            
            String textTpl = "<xml>"
                                + "<ToUserName><![CDATA[{0}]]></ToUserName>"
                                + "<FromUserName><![CDATA[{1}]]></FromUserName>"
                                + "<CreateTime>{2}</CreateTime>"
                                + "<MsgType><![CDATA[{3}]]></MsgType>"
                                + "<Content><![CDATA[{4}]]></Content>"
                                + "<FuncFlag>0</FuncFlag>"
                                + "</xml>";
            Dictionary<String, String> editable = new Dictionary<String, String>();
            editable.Add("2.1c", "test");
            String keyword = "太古";

          
             string output = HttpUtility.UrlEncode(keyword, Encoding.GetEncoding("GB2312"));
             //String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/excompany_page_c.asp?QueryString=%CC%AB%B9%C5" + output;
             String url = "http://sc.hkex.com.hk/gb/www.hkex.com.hk/chi/invest/company/excompany_page_c.asp?QueryString=%CC%AB%B9%C5";
            CustomBrowser browser = new CustomBrowser(textTpl, "", "", "");
            String temple = browser.GenerateTemple(url, keyword, "2.1c", editable);
            System.Web.HttpContext.Current.Response.Write(temple);

            /*
            String textTpl = "<xml>"
                               + "<ToUserName><![CDATA[{0}]]></ToUserName>"
                               + "<FromUserName><![CDATA[{1}]]></FromUserName>"
                               + "<CreateTime>{2}</CreateTime>"
                               + "<MsgType><![CDATA[{3}]]></MsgType>"
                               + "<Content><![CDATA[{4}]]></Content>"
                               + "<FuncFlag>0</FuncFlag>"
                               + "</xml>";
            String keyword = "00019";
            //string output = HttpUtility.UrlEncode(keyword, Encoding.GetEncoding("GB2312"));
            String url = "http://www.hkexnews.hk/listedco/listconews/advancedsearch/search_active_main_c.aspx";
            //String url = "http://www.hkexnews.hk/listedco/listconews/advancedsearch/search_active_main.aspx";
            CustomBrowser browser = new CustomBrowser(textTpl, "", "", "","post");
            String temple = browser.GenerateTemple(url, keyword);
            System.Web.HttpContext.Current.Response.Write(temple);
            */
           /* String newsTpl = "<xml>" +
                                            "<ToUserName><![CDATA[{0}]]></ToUserName>" +
                                            "<FromUserName><![CDATA[{1}]]></FromUserName>" +
                                            "<CreateTime>{2}</CreateTime>" +
                                            "<MsgType><![CDATA[news]]></MsgType>" +
                                            "<ArticleCount>5</ArticleCount>" +
                                            "<Articles>{3}</Articles>" +
                                            "</xml>";
            CustomBrowser browser = new CustomBrowser(newsTpl, "", "", "");
            String temple = browser.GenerateTemple("http://sc.hkex.com.hk/TuniS/www.hkex.com.hk/chi/newsconsul/blog/blog_c.htm", "V1002_BLOG");

            System.Web.HttpContext.Current.Response.Write(temple);
            */

        }


        public string findTheMatchValue(string htmlCode, string regexStr, int index)
        {

            //Match m = Regex.Match(htmlcode, @"<title>\s*(.+?)\s*</title>");
            Match m = Regex.Match(htmlCode, regexStr);
            if (m.Success)
            {
                return m.Groups[index].Value;
            }
            else
            {
                return "";
            }

        }


        public string[] findTheMatchValues(string htmlCode, string regexStr, int[] index)
        {
            Match m = Regex.Match(htmlCode, regexStr);
            string[] matchedValue = new String[index.Length];
            for (int i = 0; i < index.Length; i++)
            {

                if (m.Success)
                {
                    matchedValue[i] = m.Groups[index[i]].Value;
                }
                else
                {
                    matchedValue[i] = "";
                }

            }
            return matchedValue;
        }

    }
}