﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Windows.Forms;

namespace WechatWebApp
{
    public partial class forum : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            String datestr = String.Format("{0:yyyy}", DateTime.Today);
            CustomBrowser browser = new CustomBrowser("http://220.246.12.161/testing2/forum" + datestr + ".html");

            String temple = browser.getHiddenPage("forum");
            
           
        }
    }

    
}