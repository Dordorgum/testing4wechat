﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Windows.Forms;
using System.Threading;
using System.Xml;
using System.Text.RegularExpressions;
using System.Text;
using System.IO;

namespace WechatWebApp
{
    public class CustomBrowser
    {
        protected string _url;
        protected string temple = "";
        protected string defaultTemple;
        protected string keyword;

        protected string fromUserName = "";
        protected string toUserName = "";
        protected string createtime = "";
        protected String postdata = "";
        protected Dictionary<String, String> editable=new Dictionary<String, String>();
        //protected string debugstr = "";
        //protected String viewstate = "";
        //protected Boolean queryCompany=false;
       // private HtmlDocument htmlDocument;
        private string menu = "";

        public CustomBrowser(String url)
        {
            this._url = url;
        }

        

        public CustomBrowser(String fromUserName, String toUserName, String createtime)
        {
            this.defaultTemple = "";
            this.fromUserName = fromUserName;
            this.toUserName = toUserName;
            this.createtime = createtime;
      
        }

        public CustomBrowser(String defaultTemple, String fromUserName, String toUserName, String createtime)
        {
            this.defaultTemple = defaultTemple;
            this.fromUserName = fromUserName;
            this.toUserName = toUserName;
            this.createtime = createtime;
 
        }

        public Dictionary<String, String> updateEditable()
        {
            Thread thread = new Thread(new ThreadStart(getEditable));
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();

            return this.editable;
            
        }

        public String getHiddenPage(String keyword)
        {
            if(keyword=="forum"){
               
            }
            return this.temple;
        }

        private void getForumPage()
        {
            HtmlDocument htmlDocument = getHtmlDocuemnt();
            HtmlElementCollection hc=htmlDocument.GetElementsByTagName("table");
            Boolean containdata = false;
            for (int i = 0; i < hc.Count;i++ )
            {
                if (hc[i].Id == "wechat_forum")
                {
                    hc = hc.GetElementsByName("td");
                    containdata = true;
                    break;
                }
            }
            if(containdata){
                //2 columns
                for (int i = 0; i < hc.Count;i=i+2 )
                {
                    
                }
            }
            
        }


        private void getEditable()
        {
            HtmlDocument htmldocument = getHtmlDocuemnt();
            HtmlElementCollection hc =htmldocument.GetElementsByTagName("table");
            Boolean isfound = false;
            for(int i =0;i<hc.Count;i++){
                 if(hc[i].Id=="wechat_editable")
                 {
                    hc=hc[i].GetElementsByTagName("td");
                    isfound = true;
                 }
           }
            if (isfound)
            {
                //column = 2
                for (int i = 0; i < hc.Count; i=i+2)
                {

                   // byte[] b = Encoding.UTF8.GetBytes(hc[i + 1].InnerText);
                   // byte[] c = Encoding.Convert(Encoding.UTF8, Encoding.Default, b);

                    String menuKey=hc[i].InnerText;
                    this.editable.Add(menuKey, hc[i + 1].InnerText.Replace("<br>", "\\n"));//Encoding.UTF8.GetString(c));
                }
            }
            
        }


        public string GenerateTemple(string url, string keyword, String menu, Dictionary<String, String> editable)
        {
            this._url = url;
            this.keyword = keyword;
            this.menu = menu;
            this.editable = editable;
            // WebBrowser is an ActiveX control that must be run in a
            // single-threaded apartment so create a thread to create the
            // control and generate the thumbnail

                   if (this.menu == "1.2")
                   {
                       DateTime today = DateTime.UtcNow;
                       string tempurl = this._url;
                       while (temple == "")
                       {
                           String urldate = today.ToString("yyyyMMdd");
                           this._url += urldate + "c.htm";
                           Thread thread = new Thread(new ThreadStart(GetWebPageWorker));
                           thread.SetApartmentState(ApartmentState.STA);
                           thread.Start();
                           thread.Join();
                           today = today.AddDays(-1);
                           this._url = tempurl;
                       }
                   }
                   else if(this.menu=="2.2b"){
                   String viewstate = "cJJ7i5LAI7AxzXl78lwBmbazb3qPO46AC4G48HCmZQJBuewGoPJju3TMtGClB0+EUo4PzvcyRgi0Isy6zj0/2gyPJ06k4F5W1tmXOm48Jm2kbKrbelxvZlPGbUB/BXJPnCldkk+rl/NNq9IqRD2HvDRRPkfypk+jzQXYUPpGG32CkMcehzECS9ZKLqSlT5Zk7ytO9lZXe/vhICzUsCMzSAWybC1vXn2363/MvSOkatafjph3AhKf7PttsJpaLg16AXV4C9ls3B4OBy4x2NvXWJ2PgO14iLwk2jF9QfiIj3BnRvjsIRobsy+gXdrj7vtHHZ1yyN86F/xmiKj5z2ABumTXHX8wclnHptmsZBXwcJD9YtWZyurgEP0GcSVHczSUhHFFMMspAro/wdqGRelqSvT0CjHrhwnRmNUXoil21nwCwbXjhTlWn3H9akjYTCBI95+LDPte8hGtMzbwaoOo21u2U4NEqobMcgRA7VHXV5zw68SqBLuoEeCW+RVs9S6ZEvLThNhfd6QH4Xo1RvdEoJiluX1zPbd5TpvsXenMhQn39LrBmnlyxEuXrnX0vZo5KYn1bTzycIIEHueErcgQqdHXSPBRX6rovq9g5LLcFT+aU5LoA3WG9zjqZOHPuVA4VVgVS2jHlbr1EA8j7KqKZ9sEEydnP+++ZtiK+lS/BaXR4XC8bIIiI5nUlpq9jySicR7YzMV5TKY4PAwiY0tCKe5y02E1OTjZGlSfPQ97UCAmuJF2RwWCYOOdDFUMyXdn5kbSnWiXxk4qbFu2NqMI2c9IBqvfLJ0Z2umvfCUtHeYzNInsU1pWEVHdzcZZ9ZKw5S4du9pEhOjboT7Q8IVnoWgPIOrctrxMB6yyNzW/E8/+6WoDKZ2X7fdeA3Nj2azkYG0+59dTtTa8LjJVmhc+XU3RtsUlzW1u2qjjYvJgmK6o2Gtjv7c955jmRgLeTHGFuf1g6LOVugB+A6/zpq+GdViq9rADTIczDDJ5ZCFLEe7NovMH0n6hUmp7uUCD6+yVBe9XhXM4j+Zfkd98QLXP+pvCKIz/6BiVKHdc8KPW2zwJMVWqJhBb85mNIbpNrcfznSBY8/6B2SUhlkuXrmonEsRRdSRrTrf5tTOSeSGTh/zeqmmUGlnCkn0HB5Lh3YNv+Iji+I16mgPxdP7/yLUsJZ/s0LYZit/WyYaMyAEWbq3yDGjPhoyyzW3p3xmmjmrm60Y6i/5+0ttS9vXpp+FVzqrR0K2e08o8hFZ+ibcBYkYsDVvfRcotBlBtxVieLp2O1XiWYATg6sWOiM54yfGJPONNmTGHaMjAYtTD48MQjw0AuSQLqcoo5iCV8XYbxsL/ei0mxrZYSvfWrzCL+WTpRs9ZSrPyuBDsgL4G0LcDE6Rss60NQoytT2JuTXid8dA+ZRzbPhaPnCzhd98gw55h0d3ABXrYTHDVs9Lv7Yz5BjqA9O8oqq6eyKAqemH4SmrXSJzAXQZ2Htl19IkbJkwDJ/X2gM2ChJ5r7oCFPSbkNCl1UKSspXx9OKcHPee5MwrIDJmlbWM6dksm8lYcaPnc3CXkwln7emD07pdEjYv4a0I9PBCUuu22V7lthm14b//RR+TawNh9vTp6eyjNwLB9bAZcvBzwImrvk8LQtCUlELU35f5XSTokn3ltGHHjVYBME+iOHpTNTiHaOrHMYFHk8B7K1omu0Qv8gz9afoAH1g1bO1J6S+n5COVuF2IZSnN+/z1aPywfmUkRDv9X5u/mCwHiQhK8Z1CLxypuvGNkGwxlgehTPi86jXin9yjEfoKzRYZKhM6G5qSL2VW+Iqi/3/GFGwPRN4pSuEWCqqDFakDVkLe1s89FWcUG/gbOZ6bQdRTOFLdCC/OYyM3Pw3g9SWuol/8ncB3IXtHXYiHJ3nI/Yrn6LFk6gFeFvdDlIyv2Pm1/THPlfn2/8jo5sYrUO4B5UOunj9qK0//25eMieZlHCAf6kiE5N4E2dtm9xdkyauLWdIIh2QhDN+5x3EwsDM+wuiMAOpK2NiouxUu682htdr9k7OLo6+y4oMRbZnDqQAm3aXX/82VKIKAeYZr+930J+FV4t2Xf6lNuwoe2a3nSePlXt2PmYTljQLz1ykKkBdE+Q4T5DBqWA+KE4OysuUDSP88MZ6XrRyHXfw45MSTqcQ6RDXL5WHB4IhxqKWKibfx+W3kMMskEI7k+VwHj4xGTfh2MKHiwrGLuAFm/Hsmg28njd8ERhA34+EuWOL894kSIDKttsu60+AvfHBplvQadAFKDPDZzjgHpaGNUOf6Rtelm+waAmIL0TSZE0hEarMKTEdT9iuZx3EgVcc2alTuvfakKaCIBzGuqDyX+meTRKM69yfKAK2SeuRLSiSPOYTo2rKMqe2Db9NdVLJ0cNFHGyYZnNPo5OrJd5cme3R10YILE6K3iewpiqUlBNUABy1jzAwW/tLJEkwwxQ2aHjqWoPPkKsdGLOJyb5IqPXHNF8Hjm6DQX8cZRk0E02PT/NytdXihnNqx0tS6N+DKZj/aeaHfefmyDMxPbqrtJn2BMCAOuGBhymfpDZlYCvFrdPmuVVxw554H5hfP3Lc0M3TmuaR4BLGKKtmkGTAjKQRO8debuY8b/Goe8YZsaO7rQPdJjI0GKkp8a5f+N0w6sVday4o32/Tgu1b1PeM0WO/D3JXR9hS9FanocEDa68iGS27DScV3sZQDIODCSF/Gn09pUsDC1JlI2Xu6Nu7gF1a7gNTesmzDNNO9ETyc5e/Ygcl80XGbYb5ODm1IXJMYzuTjRCHqTVO2MHG4NTshArt8fzYLIWS/GW88FnZNJotc+J666dIEQap5tshul/vX1GHWru9HniX5bhOWMXF4ETD5slXS+aLjPdC88t45BkETfcDvzmEIp3xk/biAmsBeedOoQDFEyo6S6dz5la+VJyTDxmMRnI40jY20HttzB5ncusVGc72EFWFdacmrnKIxIM9VMb98SRmVSpQ9R4cdTmxj817RkR8rV0bhXrIVevqRorMwxvwRT5LL/ZftgYlEe1ROqpoFCwbqqsT2Kc/f3iaZ7EPMNgPf6gFkdFRFLTHt3MIr0Q7LQ2MyZ5ANHhmiC8ClMYB8udG9DkLuDww4Px/rEvyWmfCag7voFkS/6qnLCPbmvWrWTRpgfBujm0eB0/b24ffvNpUzj/QaVvqydBuMOKoNjF0ahh36FjWfNkIyMmxJOZVikH+XOp6HUC00NxWo6e+vs1/z7ojh27M363A32ugZJEZ9dtOlt1AP4YTtl29njeA97jDOmzd+mvUFdamT14QAXJG4oVFI7HUA/YspRP7MWEM2QHIT1k09a4rTuGaJB7U+7TlU03MLRMQVLF3wliz1Lta5q7sf6HnjiADrSSpccLiyDfmzgFKKgeNSPLjuetj7wcM8oNAI6dEHMNDgczBtPFcM5e1iMQbGwDjcd5xXon79UQyEECEjV94OheWtaRMeOgibZ1z4EVKtZz4LhK4W0HNNGIIZ0CAZSKO/zzVr/LQWL3iTcoE130aDNA7HfUnLsz4fC5ixwSpR8cfpAasFzy1o0yKWHXF5KjOHkJnnE16Qu87VjqcHAxyjokSqUpLnF4WT+UFm9S7Wh6ZciJgPXUnc3QYQ8CmV5Hx1jNN2KizH2KTjYJ5B/z6A43yXuvBroiA/ViWdo1j6wY/56f/5JmM4rRhmwdGhD3a3X+bNskbKWvnrcPRFgyzUOGXpcfJ+kzWQ2Da9dQgHrmm006BbWIbA+dv2aiF7YH+0YuIt6r4uz8w8SrLtwhBd40PwICjQwxsPasw1htMh/1k78t2gjbVz9MyJGUYXdeuxm32Xp6iSOwNHgyLG5mxiOYplG+lt1UQiIwtjthV2V31IipccWO7vBtYvGBZgyCffYbtyCHMTFLhcT7LoCHDW+RGUtWza/Tt5EPmv7zhqxH8Et1zEP3tJuOPvFXo/PlraC8Cm+pMmBO4SYUguepJLr5jmdlbp6RKctOXmxDOCWd7i2pQAZ88ZAaJRRLOvKMH5ZPchd/C0NcXfk+N5u3tZu7rdc0uYlX81ySQeaKAGBtlUkJF/b1ACNl/z76PBBzEAaJGqIYLeloG6ALkWNKKLz8pVCMTF3HM2gN0KYAFdg3G+KyNVa29lX6A/QIl8SdoRyEX6+H1D0ehmt03DmhgcPo1CywzU+9l4yfWGNVUh+q1TSAJ4NFc78T57HOebcy0wcPPQbnK6nQ6B9e2jGkJchZrTPltj09alnhNYU6j5j+IvLWtW8V/SpGSgwowDuWPknusY/t8Ebi80v+NWjsqBesMYijHgbb4kQEx8p1aVpB9EoWBykRewrnchvfit93y53qegy9DrkD43nHgF1CCq0FYJhrf6TruowE9/CNMkXdgOZx59TO2zoLCqymLm0HBXclu20LrEVL8Q9y4RKoGR8/MI3sXT7H3HET+t9HGp3CxsdH/Iaz4NloPBkfIZOI12twDMKyNor/PP8MNjuIzD33VEsa9qddLVR24vL5U3+6A4QlN0nDlxoQyP2ii9w0HPhtkwyZiBQOIqLjYK9BaQDZbOtQnFxwTpwAYa5amMXm9x4VLYn8mexmtjEGxiA6ZNGPNPddRnUgQtevWX1EbM+xVx806xWIH83TLyac2tQ4iZQGUoTLFfg1hbK5XEfuvYSQP2IgKmr8yAeUeBZ1gitsQiogeYnGquLF+i8sJAznoqUCr3DWAOn9KW05H1uk73RbEjZJ7SsEJjj/FbqxxyplqNzXeF0ugm0Ly2M7y6zv/EAjp2KsvyOyJsHAnr9zucPM3kFGaZekPzaIS8SAstvIwayW5zkeSzG/1Fxa5R8c2weBw802N1M3791ZvBR7lmWytak6cYbkcZKd/kBcB1ljkWTqecd0jXD6p80gTCs4UEPvJZOg1bOsDvCGoBngFgkimojX0V1XIr7uLpUCsuEc7sCl8fZgnUMfhNqJlKXRIEGtLD38/g5RbCXxkFXU5SoCI9fc+2FS9zScfJ3Ck2agYwpO4KNBHOEuTWBeDvy02Og+nGlVRVt4HRkPLtzMQ4r4j/ZCL7VK+N/hrgb3UBhxd/l6zsflfwN9DNCWTtModSbarqjktE8eJsYc6jEd8H3o9wJ3RBJrkQTwAkQg2MonGM27pqjjqPcb+5sgWQhqDzMBIQ1ObcHOEuX3DaUo5epDT3n+4VZTDyvnmQ7jMhI7z2vGPp1dbhCB9F+DDCtZGNov0Xr1v55aXMxSSaAtJsx2wfwrZvniZDYEaleiVi8Vehb1BExCDN9wQjN0rK+cU16kVvh5l6CARWnx5zvkhMEcSvA8/88PQDWQZzWiLEgTyeTcmob4FHM+vNVEHucgSGShw2IdDU/+F+toXb8Mu3AFU5DE0v3i2EC6o7qbwwPja/fs0Xy4EyqpKo/m6RAYXMBPP0/WOIjarLlzcn0DnV10iNSwDZzWDDkclf1NxCJSwYJwP1uQGTAXvoJVOJnoNIYFxLj66DukiZbGdNPHlAeITjKcv+wejc1Hk3pGYtHKkIL8pLO5Pm8fyjeJWWNny3k6a5SckkRFMyy/Vox7CRMv2vq4w/SJQMz7OurHCdmRldK9u3GUGO3LlpUn2LxZum2uzN0yAxkAgd4oIJ5z8ZwhtBtIq/YCAOUsk6GNUBOW5ummBvrRA9QqBzr8WjlqO5jrjdMicYeKQS18v75OBtVLMnNuEL/tCP5qEMDp2tUPdWyM2VuLnNe6GW9+LZ9+gqaXJlZDWFr1O0rEwygbfKGc/f2O8KJAep8yKkxhdprgc//dtjwoNRaIQS3gf0cjCYwJYiJUtvGVLWr47TkuADGbRT7Uaj0HzBPoyJMe4dFuwrx8tK+K7yeCuNlCnQMhiuUJdmERTM7rzYMnvhki+KUUzOq003puuQw18XsTRclluK7pd4CjD2gJdpDu4250hTh/9gzWzsuuqbh0x7/lIkI66SPUpypF6nJVsVE4zyg0Mi4tf1x29rsH7zc40thb2z2dKCulcwg7JInKpvos/2S26K4PcudoUEfVfp6lAksjDdokP2d5MA5chw+okNhEYZjvJR3oFtO3zic4QzvXWErxLMiMmCbBVFhYsLClJ6vYx/A/pRcH0pUEaBGgSErecqj+kE7s95OWBej6idIZdOn+LCvVNWa9wObqDSoj3F7HLj2i37rrsnvucrGvV5agz1xOIs7k1PEsFMxdCiu6C29Tq5H2cEJGb54I72mEfujjY7gNUnT+aSPJHR2f6hNelTpEMNewDXsJX3CUekriYeoWEGIG6TX/1sa4DD/AFW/b6g6a+saCCGbjSz/KHgncAPCrpnDL7vwP7GZ9yzAv5NUCtuCsGQ7Kt3ZqRz+46MxAe7n3rhBIGGGcmx0dc7b2YpGtwDAG69k3PHIzSyFgKI/21PQHU/PkW0n5F8WVRhiNmweVRCIn7WKmoNYeXVMgFzUXG5QlupMEEoxVMugffbcX389p80yS7tsfz3XMAM23j8XHwMAyi90iW7AwKxvWiNfh50Cp+JautQGwsLpji9WDrNdowcTPO0W/vRvqESb77/irzMObiNL2KS45wFU2a0FSwUcXGVnz1FT4gH4BZSccgRPcwaLWTmXZJraS47WfHAwYoDLvaMFv+65HXqCgaQpFTRJooRpDqrokxcMtw1VZSGzP7LOkL9fqwxqCK+1AtJS1aFojrG9gzhGnbizn5rmilJ8fXSciJZnPAvKqaPeQLr6LPpEngt7CZ9t8G0z/AsgYFGfVi0gZ6+tS+psHiiQhNoiB1jNZsCkI8bB6NEonHGKcffuUy/ZglWGT6bmBxNQ+ZCL13dGWHnRa+ix37WMgJZLNIhXpB68idB5rJfCcd56goyBJaM/ElAuYBCv/tIAOQB7ZORH6dQd3LQCFOFmK0zZ8+dWS4Od1FxRz5M0PNGmoWpnuOTWLvn8bPCHdGngw440tMtGc5RlW7Gg4XWNsgCDNE+SlCf+yri8Ar9qQ47Si4+mIXpqj9l289cp8EQ4rCNJlIXLa7uLkzhVDvVFqOX8JGSVJD9oOaNXGjfggdKozv/ehfFHNscPVswK0gVOHxXDy57VLcrhZsCrKppvJso4xTC2YhgqEjQTbomJ+8CIIAFHcUelST79DgJeLA+Kd5LzhpmHiw0zKsAIhWD+vdOo8cEwJaITQJw1WdjEPc1nN/7qZ+QchFvgGmZh9Mwt6W1dwnCvlUypwSjUSKy6k8oRqkLmUfQBEVVrX603uoNpDzV6MKfW+lovnL/xF3Qk9j/P+dSyzF++DeECVEXvOy9BoI9TOZhFYEK+fP1UHCxH+HTvi3qYB0BBttNaZAALgcY+rqWgr84tFwjQJRLF4pAFB8DRtxI/zxJ9/aMKvixguv0AafaVNS/I2ZZZroL4K0GJBxcrfByYwROMh70QgYKAT9om794ijqHNPie7e5WfUGasIEkJTZwM1CfEnRWlM/e7w+TIzIdwxG9cwteUrHtHIMGGxdsWSFwOrliteRQAR/L5cVLkhKVj1Jfy7a4kBlC/cb23k9IFAr3shT9x/vXyt9xJXWvR2rzoSm0sGBIlLEycmc3fbpxnY4eyTab+/NjwmA/SiiHEYNN326qbznrYy3PsbI9rcey14jBkrRW4cdTIJUA/gRo9QSLd97YgB9B7QvU/ee/ISsOeblpgAjfzjU2qMYcZporWVk6fQ9G7ZbNtpTfvERYOpunrQvxXVv6sbnP0cClo68gqSDCmx2TzrzzMW3cYcVnkAvGD6lu4wYLPLb+5aBupZIiU91riZ1LQhMItuGMK4+ZRd/vpbQmN/Nu2zIr/fnGnBlr/vgoNUnoQQUsfdEhni1K/157upqv5lrh2noYojZedlyYC3aLI8/BPmVDpPqziHRPDb3m3C+vCLviXlSRjZPxEfUA4VXwmw0S8cjK29AGh8s3A/nDuQA5as0HXs+/bYr+TqwuayWaI/cLw6x3gqosfZ6Yyav0m2c/74ub0d1gSgNvZvrVGM9ZqPLbgIhhIoXkNpapmKZxzm5a+MmcH8wrc2gXfRs8qohztDTLxlJgK0MpssOVtcyjLoYlLn1vGkEZpUPV2LvNo+OZHo9xcHmKHZPT1tttNf709ZWOHWEHu3LiDmwNsQabRbOQ+0FPsIldffSP6QSsee3D0dnUvCH1m9DX/nP2QEUvk9JrLVAziS/SHtjaz9E868aT82yHczTaW/ewZpDEzx2wvnXjSayjHgP8YwO7RSBlip0s2iQfihx/1M/uNyAH7SIJ8/+sM7MjEqc92+yyztb2JrfMKEs/1JylR3pIlen+T3QoBykVd5jzpD7ZWAwwlGmfXOfcy/fFEOUfgpClUHYbBLM0a/0PSTqcWin9QW4jd1b9t6SEC4Lyi60RUNG4eo+nkPb4Rdq0AfXIewnTJhYsiTg8DMcdpGugKcJ5Ft0C3rspTTmQQbguavofhfPGZ56EN54BmgPxQCfG5Qdv+s6DQx8c8/32/h3yddv1jc8P0Ty2d+UXxca5qOegKLENLkvhgcsB15y9f4HeLvU9QPqhUN2SBOdjgdULuquNtgz7WyJxiOEy5f0b106QzUiAN6fO94pmXTyP4lrRl1F4esOt1zY9U+VhE+6ymkIZD7h4HRcb6mdaKuYwmdqvjdnb656BBjRVpJjiwj2g1/KPct2u9Z4DrSMttYg/nOqd3pg1dwFAVqXUwwFaTJon2v1LUTu5u4fcu0FgClNN1SNEZ0sPDTI/STkDyWumwZBa0WGl0+cibB/w5fR11U/qfbsyivG3xPtJLp2EON5F4NXBSaXxW8BmS19vw84ULk3KXvyqVqU6W700Ma7+ZaHBzoGnNo/z8UbnGELzxcE00hi+zObXbJ4VC4OJtA1hHYZo8LVyyF7dcyyLWpaudazF9tga1mBg6jwVufeZk9+rulgLTqXXC0+ig7Y+xvt3MgvshipNIUFo9DaQCrcivZFf49FwH2VVk6T0Q1N/KHemmkuATRDF+p5twYRJf0RTvEQbWS/mKfEvpyf51K751LuB0mwgwSoH/4zbzCol8gHqfovIZQXK0K7dY24pzbPnYZTPlNPUj1sAITzHHRyCJ99OIrOz6fPuqRX1Dt1zp2Mit8Upwq8W4SphShZ2aN9T09tZeGdwbdnA8jPrGeYUZ94owXCHYoGvwpSoT+KOYn0hWk3XLKDx8MQQBO2HNEjZ9B3eAyHjX+rBfgUy1A37/ZoeSngJHBnvPlJFIMBoi7DwrKPeib1c8nodpwETaJNClArmDGEhe9N9DcVbi3dSjPjrHdOnfXCXL4OuBVBGivdhVDXGALX9X732A+Y25VoLgAjRlS9PrBpUbi2GTKlpjNAkTeI2rMTOLHWjdCf9IhOJSPhMpZq8rXY4bddTX+ERuVsi0Jx6/c2JETkyFRLW5fvXerRAwFt2xP7YJELcTMNhrQVsFLx406nAQpdUVMSHhQgBd8LT3b7TZ33SKuYIn+GvL7/D8dPFuRbCU2jAZdrNrDR1r+3j44yE6U4VLS30AakTFfK6H9kwMjUIOIcDmUvrEaR6PgDyV3sNeK2rK5nmrvyl5lHVii3xXl9I8w9K/YkM/joGHUBPPn/TMPK4a/dko08sbV8cR27EFp0RWs4mBY+adPNeNGzt+d0kJjnKlh1Idl4UypcNiB6FYzR8/edlPa0g0GlrZ4Cr5E5JFXbhks1xSLg21vDe0RoOLMx/DhLzxdc+obWLL/1BMgAFb9WtRvDD0PUQJrO3IuCBxmeAgaY2cj3+7ZiOCNcy0TNLZfjSZ9X8WysW7gLJeOhxAh4ZdJhG1CfOnm4qMgzkDi3OuAmzu3AW37XcOb0muOuVn4SmuD+dwc0udM+40FdAJJW2rufpktVd0Fc2d6PLSNR1NHgFzBnHeqejKCj9AT8qDwRXwpMrzit71GKEFojACb4A0PWuhTC3jD10zsjxaTUQw9TbuxkBW+tZccMP31hcgHmWqjIv4DpbIp4JunvOqEF3+yvOMzV2rTWna3GI8MQoubLacDD+jdtg81kSJeMbd/rnVt2NDFngpf78OOCGERue7pZXHnSyaOlGlNtXA8MJLdaLN5MXVCr4PifpuY5xMZGh+Eq1+BPzl3si9g5qFxjM26c7OheN2nbrjgT+DHxlf8uVyzo0EvxxVpF4L2VggtH7xUlgALIugErWyU17rT20krw/AmsuZrIg292m/vz0RJJb63xlvxOU+JcuYoyvpX7lEftUAOBB/5T6sRhKsEwczUqX7h+u+UHlyefTyc8h59lhe+VCUJCUPe68phpaojK/bR1xNy4VNFKfs78Fs3QfSbgFIaKNHDN2g93hqm+UJ2BrfiPbVezb3tfFgfP4huib1lrNXqwzWQKd62Hm0X8uG3bjPuI0NIjBFLXIJ732f/TPn9OrdRUetMx5jiyGKx5pzqvJjXOhSfFPeqAFjZ7TugfnEemxUCg6abVeGi9nX5E04XkwErGBTdxakBea9CqAEjSHFK3D0bhIyUUrdTH1+AVaYO91mHGuGF7myWDW4y7RC2yU96pSiui7gC4SaGcBbuNbTppOY4eyVHXa+TKvNiFX+EgYHaT5gov0tQi4gVnDJDQTrHF/SwO/8i+UjFolhouA8793fcBGoL+EwEQCfuHDbMmnaSxD9ZSPYtG7Ue7Y/n5ZFNn9diOaZr+Q4XHiP3n3UI8F460N6W9yLiQooRd46L/PMc0YRDE9A7JfMHgbIeWDQ83/yhj03a9lptFUwHNNuOEVL8bap3yAEuI3u5LYIbt0WB/OjgC2EuIUSDghPFm8WOPg551WpBKKd+BdUdspXMAUzq/l/yvpcEl1GrPLq0xycog+VJjlMu+y9hyTT9xPtilxxRKFMCPYlfDzFjfRLqvZy0aFlbYNMgQgHpGEXPvtkb6wtTTog/US7f9FCJRE1BYzCi18VdEYs7Ae6zS9HgxAs46tLPWom6UUiT9yw7M8Gv8aq+fjdR6H4GIcAv8mZT1G6CVIMzA03wuw/gs6sNP/r8ZP6a8CxJNSnJmtdrpKaNIQH4UTiACwI+u5vRnFv1OPTR58Gp8vdDm/3WI5qvhcXyjulf6lGRziKLj1JV4YSsuFgP9iJQL7lMpkbBuqxwfMG9BGCj5cOEfaKRQ9o4NKt63By+jtnfiBoAAguNIspkwTz2OM8IAtXf3bJHfPx2Cz/Umqr61KdNwMhFqmyu7XdGavv28Z7avBavSHSvvUt9BjlCymgjToyWsaaT1pqttpDG9FRXSxE7m+pRspO1pE07Lg6HicuZSZbC66tk1jez10Xbrth71hel5WVSHpVrHQ1xuor25hY82sRdD/DFfCTnb8+kzdu97rCsABHQ2o62tkW8jFbEMn+qan13Tdj7AjIw6xfI8J6eHfNo7VD+rmqCihKz+1u16tf+46gF3Iy9Hu9m5pTemENXCdSUSDqbdwmmqdgwIwo1hAPdnsifblDRPHoBaBKpqryWrarBjCdMZEte4D7sjeSLF8DGekN5UaNHdH3th/pGaeqAhZLUwnqIiKXFW2ZfB6xjXuGZxaaCcdJ+bEW6M9bbq2VKwe0fhncZkfyuPyPuTLMX0131OnWIVgCuv8gBSkOGz59zN56MIWsCtiqdXoe66jKE+mui1yduhHPm7sdDCxQFglk+S31Xo/D8TK7L+f8t+GPhOcihZV7qHdnd89tMlNv2vQsrVmQofrnx20gpUqbOj3a1T40JOihS3y16Xod5Ju0YMzEHMBfcn/yEHo9+b8jZfumzzt/V3NSouUAI5EKlF8gD1JZOBRnI7Ha8bL6lVvXgFZlhcg5SMNrH9P1CvRI9OY6dayCruTbgYymoWdceShk8QqbvnCim6yezYHCjIqmUrtMEN+OQZ1pnTKlsw8CoGsRy57N13gkoeeLpggFaWkwYXhCNpFi0KhyHdcHdFyo3OoOddT5mMwphfnUeo/8YMagtKqmTLZ71cA6WMnwJA0QV+Mu/5vd66jFsOiPOCTWF1jy3EpECBtVwn3yM+gBFdKdTLFe5kVbzEuFkJok7AxUWOGG0pjmf6EslOVtHI+XoY6q+c48gQjN+LZ93LgZKv+0B0wGnjI5qjN5dNrgzanIuszzq8UBzrp2/e0DTCe7QDiCR/1b9BOWgiMFQJXRUWhVhqVKZMSgZeaXrJ1QpmMCNVmpIBxzFdy5gUWU/GemfNeAFnBDJP9XpJ7bDK2PbWurfDOTh5BbyZX762KsceajlgpklLv1pJSHMtg349hchL8xtSCmtVoQr2k4g1OJ/jgzI3md88a+U7QCV8QPoMl97sWckiAb//1+trk8ahkaVyFrzKrvVHVojDvtoqA4/m6X2MsllOa37W/wCiAUxQKPjvOrVY8dXWXK1D7JPI1BWi73rR70a6iDQ2AAaaHNoYkfy6FOHOCszHP+SMC2W4N8jyFXnTc7zIKkTCx0dj1WExXks7R6GSXzrUeI9Ft9J+T7ndrTGT4WNC++xdctwo/fSaTzYxjaET8qFFCEEuURDUEoTxcTnT/C+Kz7nGzNyld/2mKf+LBHP62Qlh+rWw+9vk8EfmnMvILlhqB/lgZ4kkyZnhyRdcN9ElrKskvVfWW/TVel0s37OlSAl1/AJHU7hpEYl6ZqGqS3jh1ULvzhLkmsOxe1i8AUlaFErEFT6yHBPWI0ROL7sCz2TOodZr3YWcG3A2uTho4OLvNi8g0ChMxCo7a1yznI4j1TNvhDsKq3QGWMEQF0Ssi9/LsEKqk+AdxOutGOM0Y6Exmdg/mfnkXkDKmn2zqbY5b+Kwy2E3x7W2z4VaHJn0MbRPtoaf/aG9Gdbr+7KZ3CBF8jZeH5OELEzfI5jwb6dBXEcewrI/E+oYtYXubW0C1qV2xXPk3SbPQozIC7S0CkfsDdzv6A6HMjGv4GKUk4CDvad0AKMll2IrWYbv1piU8yPwNKKQ6Dn+0bpHCGw7b5eaTq2J89NOH/RySIE3lBcbNmIcgvJyEIa6pkdRhce4ldhpl7sOxpo3Xjs8OlaXLrr/bQ351OW7tJaWGs4V78IK+dXjJi/qEPG5PsU1Fl/+UCw/QboJEI2qoyvl+CrrjLbCncrlTaIQdH/QPiuTj/aITKQDjpDCt46eOHjBgRtuxAG1z29W7X/hrjWpBMZ69cXtFrbQ5Fz7AP1DHpyYWT9BRcFviD9FVkMGTpBws6U+h+hIqUSKZD+Rk6O1DjpSNbBQt0+SvhCLwGx4bZc4x7b0XfiOpTwoKAIiJ8o2QjM2meYWBStc29CnNCxDFc0R6XVQFYoJfYz9EICl6tK0o8Q2ob1NTlB+kDYJYH6WVpWcOnh9u9p0mAc61ApX6JbC4QfKC2vmOd9tH6pdivf7Xxhh3bD+gVI3+KiLH7mFeatsk90sulriNmyYr08AqEvGbypEQ5UycyV5AmMfjWitptL5fPooqsOzCVIkNCpWTTNq51gIeLIUUUupbB5LYrE/tQWNE8WZbfEjXhc/ohOAxyKS0KrirtbqXtmAwRGLSOAMefVE+Po/hhofwgFXIRI27X4HC7l15d/Vg4effj3Y1+D8D/GQfdB4ykDdBmEs0QRJ02/NhPLuNUc4jzz0pdSqIc0JOzc67Cd3yyvgT22UWqdhhkj4Q6cXSFLOT12qm/xJdXbG0mNe6nU5mcUbO75eMV+Eak68PQoOFwyp+OQBUtmzXJQSXifK77TVy9wj2Ki7nbdMSvWeFh9rBsPpbW9K+qIG6DkcAhTI0PesjQhcMYthtK4uTO7p85RM0RYIEXc3BvVBXYpN18gd/ov5SQH+Cv5QR0Ksf6aA7KT410X1sXHwwNgDaIbWv+JZYWacKzN6SHDH/jz+MLCqtcGwa4hAs0+U2hjbZF7hM9humMoBFX3eyJJ8+AI0BbyrgnALkGSP1g1wAH/QRkJ8XezPeG2l0ypS0dcchZbB7KDJqPn3d2GkUoNGB8tHQvFfyXjTYwFdmk+YkXaEBJkfQfAWIkvDPcLuxzYl1dMskn9zzRkA9SaIX8+J4o9pMv/Y0cs3x/YXiEshGx9ea+rdlZeYkO4EXaYGCC0iQYZt3vnjRXp9kYn8xm5RGneJWeXNQPOcKuGhpgbqz3NHwXX899Q8MsJz1ShR16DI8IypjriEH4jsgdUFlqGMOF25sqdv4mBhniFY2OdOOvVKEuHikrLtjy8s3uaoqdEYE+JdH/heyKfcnj33nfCdlZVhOU60TVOBKOGXyTHfLKCDvYx3UgPsNh8ALPYA/JM4tZz0YOL+SzP+41hFn18k89293omPnH00Wfom6mCxthUi+yI9VgZMiALaakU2B5iTJHpGQk3QFUhB4Sm7UDuH3Cyk2I6qfOnyRp3jBhK8fhvNNsDX75U1PYDwz+lFLcHkj7Rnd9iALClFs3bdeYQN6ZAXqJ4cUt7fOMOTCi5zQ6ZsJrif/G7CSym67w1ZwNkJykPCPDpnwuGMWR37ocvPIyA2gsnd+Iz7i/0JtmwAy2+QBAFeTph/VV3ODB4GMUDZdFXNncdtua3jIRDg8yMqlxqfs4fTZkTN77tykLeoADt5uENlUDBN4GAsi5ywudKDR2CCnt9Y0qwXauYHwVXil8rT5eOeykBo6fDksjtDkE95JmRzIyMTSlW+cm412X5ztprN4WQaXWoDpafzT/lVMVaXV6T/WNDhlYYaYQCzxCjoAgvaRH5xHWFqvJADcH1FK7CG/rh3CAEwOhcDygCzl8bY7ivmQmHNMYuFKgZ2DEbUqgN1McVYffZhhHsBhrf1CE5Onu+LzW+7A4bbUSi3XbXwQrL6wHCizKkgZlrRIMEjMrc9PwMcXzHBHzrnB2wRrVlu1eEp4PVJ17srFxolHjMA19dNbYBELO1bPNwE1dJXjCBBJ01bgU04mH0svRjtDBtK2XX2Wutlvww4zQ+2E2iElf38dB96m9rxtZvKS2y7I+KRzYK2/wHvG7WhIaW0Z24NH6yxlZFHcH7jcu+WA9/fuOniDnohyl8L21caGz/scLIg19+BsHNnGnovqe72zMy/dZmEb8d8lyTDo021ui8/kP4B6/SN7GhrkEJvgZJsdOJtUrRHNge7Ju9O5+t9zLwdxRGWP0snElCxiLEoPA+LRFYX1HmTyCmwc+kOggObcVmFLq/87wKk0uT/hHg4ZeF+27B4NC7XfQopvyVweJgw8J3SJWymaWSlnG/9ENNcenhTfEiYko+BPdOD4MKvynO80e/GH0ayciGk+LZwjU0XV5SyJuLlADgUSBf4pToQv3LmVrZ1uVfzjrMR1nekV21oc+JyVKO87179ozlwxA70zW2Jvf8+HpA+bsEgSjfHUeuESQ67CHo3WhF82kYMFPHHJgGL8LV3xowumMqB2fTZDkC508KJ0dHQCYFn/KvQ4aZHLbYIivTobsrJpHMhLkPMjQgbi+6R2NMvN67MG9buXYjX4wr1mzZCwAU4CMdOHdaFYukJ0NiK4I1H4L45Z/jJoRap76UykG4qIBqzugay3KUxDy1+oYciKNkhCOVDDws/wiQ3A5c8e7BamDNrrAJ0/dgdtipoODSvoPEWP5/gSACt28ZDzUoHsxnwpb9MkhlExLQy1VlpXWhtzNHZCPUmndSGVO6lqRWuF33+dAB4IYcmdD1PX8YZZcFr3pgA20SWuR3jVkEgm68eDETINK4ExIMp9LN4c0uPTWezcMTp3OcaFrJp5jHyPiHNA5OrufPUOl38tTGYXS85Rv/8QrldBxI6+ACtrc+y+3kozkNOCZImii8CY0s7n2qCtCHVHSAoKKmgotjYqZH/h8s+dKc/e6MSZvP7LQlnYI5KH3tbWLjmROSb4FA+w0ZdAGCfxkFnINPPmGCn6D/nYTBNkp//dqzeP+iwes5dpPUEH8kAl3LNYXFQs8Bj1jDK15jkEDSjXCKrQbJGlk+kpL9LajPm5bugyAVa7gfwtW6BSfNtui/AuQ+Jrr8xVxPt+WyIS+Su3yK98OZgl/cocE+rEIMxKAKBisdzWblRKCUNzBd/YviGKIRMR9G35BBG5kJ03FeEFaQ9a13K1tvANvcCK4vlIRudCaQduv9nLVVP64NHjxYhYv7Se8UHnVTHFYB6VE+lqdmWVMhafU/CF854/ORYlk/gIyT9K8m49toz0621v5tEvHLRyrdmJAKrE+L9Wapf/b+TKlbQOlZ8Vd06V0bwRmpCREFunGqZMwXnGRI6SgfBkzP2orMNFIOYXzawuYRdjnMbyo/9+0d/JfMnKdwlpQBSgSZZ5og4z2So830+6sKY2OdQjakMmlpaoIKqP3O2XBvUDQ9ZQC7iWK6gqN/P2/PV/hyRUWGnxVRtf/zjOksVxlgekpxLLDbj3OihAcA77N51zKK5W99aHliyKCdog9NEutl4xIsqWWFiDIoXZ4xfHGCWoEgBSbJTr9l/9vvPajVcxzxjGgBdzXBHNI89ZP9Bt+hp+Ps7Nk4WBpXxbMc89OJLvh8xgRY4CvJebHAaGvQ2ndU//4dGoLfqsazG87AkdCHn3Y9vC6n9WcI9Sd+m5it5jqXwZ3F50n+Z5SAOppKRtJ4XShrWDRiFnnyqLI0oujfGbLxqKi0qQ+xzZnS72iG7pldug8/WELDU4b+hdNxYv/lKb7kYnbvtSde/kqTTNYqfN7HiBOTtM2gN4KMfcvWCvv5cSn2cLKcwvlSuxxOx7QIS6uriWDJv1kBb4O7T8SCfUhuVJYKFkTpyOYsH+enNPPkDTKhlTs3NUYeVZcSOQwK7BmR5WjecAmjKLuDVuORj9Q1qaRuxHkT7B1s/SSzsPhmekDij+rdecFrvHaCjnG3+zUW7TkbgGVIntAfkk9wuOFYikU6Ru3FKkYIfSthd1wm8Sn3dYWChrqoM05wCHJ0q9j9OZyaWGDY4mrQ6MIBW2HYs2Ya4BSo8uo7xZnylv1yDcFzaIbm7tShJlvI7fJSzHBU36mEm6jyrJi05yxke9EbFEw7MqUzeDC08ApoCdS0LG4n+xB1W9Qal/eGseQdFH3d//Zk5SSCneFLZABYpUwuZUWJJyTCKLpM/HBlITbUn4bnAT9PCxNGRM4ttDL1OYWzqY72XlsB6vbVZJAbm8GDBg9+hI03A2BNFOkOFtBDGUh/OnqY7aO9oNnZp+HY+pzCKSA3GBMfuHMTovCrD8QD9eyzSMStg2Qk5FrpyP7H6fPMvTEvddwCrsQ6RppdaPLRZOw6Waapu+t9gzfzciRhgJeGdUJkuxP3AZdBKntSCXngWESZ9Ozngpc3udaGC8srBFRBhIfeRMoTnH7TBsVuNN5JP++gYr1Lz1ghUYHiKdKJW1jWkOc3xczRkFDNRPHpwhHRtQQ/kWw1nh6AAl+5IpxKZ00uq5H/0gJeZQzPPT6LbiPxCz/GBc/FUmkSmNuPqEuApb1Vj0/QpRrao8VyPItRsBA1reczGd6imoj3wFeBgEGWzVw/moI5vsCIF037kIz3UGrbeOJ1Rifo9Pdbt3xuw21AoFrlKnUVAe+dp55id50v8gyWD5WkGdg9qipJf4n2LeaWM95aujasAij6aX42XIsKInx9CSdkpuMxI/qm0pD9sBsmslCezoRaBU93984LMAhzxnh81daNpVQnW5JQmWGe0by5cY+N48GLkZZyE7WW5u94Rnjm7/9WiG6iG03MAB7b1mobQWN1OZr/YZh9aa5BYWj1sEoFp9GU46DmfYXdKhY5JbuPq+pIBvT0V6MEkaQ+83mhPUDDuNPjvH7pwusVPdW1BmD+PqHS/TEdkXwBdvPQw6hz1Po+2G8nOBvexJiAMlFQBTyKdKWgr3zxmDBfWZren0LpFPN+Iilbg8UFsqMIDLqbg6pzRcUJcKw+xVDK7xEV0omvtxo6qzJJEmcURvdGDRubdaCS2uxawItQ241Tow8x9pgKFXhYJznVYmqNae8gNpVyjddDfIFe36BUTM8Tcfb0jU+i+r5d4/BdfQumFKThHaQ/VofbZ16vm2UFzjIUKS1/NnkuKU3rRmzLOyqHDPkhsUZlgXh1r/UFMNM/iUlUoi7PU1jiwTbVecoNcw7jPGgh7buJx/FWLCYMfl8641nDeIPHWEBpn9SMGFe5Rf6Ua1phrM3cJMhNuUCecTArbjNyA3hblVXXOJtcE+IdwaFsBzq0xhBziVv6V5QVqLxf5bTbQix8fEmVijdbeW0W3yMO553u2PAMAkai0XO25FztS6a8rWL4oE7mxKbAegsritwGAjwiRMuBbEiv7kmDyX3oCCWm/OWg64quJ7+dHDcCG/NrHpP/SQ6Z8xdWcSTj7ddZ655Rbeo1y0qSqeyNVBdg3iPHkbR/IgWE8bwnp0BwdxJSMSD5JZXh0InA7fDuGJ/whzix4uIuaacaBDRQOmGEwMYpPLrI1IXOxRxdL9PDKnkQtE2u0wRN45nlsz4rAXCdhZNDygwUIsAClxn1K0Pzew/Wbp00eTtWzkHiAj4oPb6ILHrPbmjnQSDuiMQ7zFB0XVexUrHyGn80u5Ncg/dpy6mmu3Rq8lOXGiFgmmVm2S7oyXkMN3LwAreYAfvoxcvVDBtpS+lwV+OD5HMXfr4lDjOfhjtfyKYd28ZX31yWtP5QvZeN0WhfQY1pGhm1TUlQ7eUwaA7GQAcDABVnBHaxzFg5sE27EZq0/fUvSniGPSnLyrP7HRd1WNHEEYaAU9lYBujHUtQyPJLlRHO4dub/JoVdOu2AmGj2hm0avAHOyQ4RAzNzkX0Rm4uzNK+j/WkzxXnwe/5Fh9L+7qDGlOUir5ogHIFuU/BQJoBvJePSKzUA0tjL0cpmhnWuXIf5kxHzd9NL3D1ZUZdiJGaiTxuSIxMakBbA0ki5dTF4wYNfO1x+m5Ae3eGcUQb7CH0Per95l9Sz+5r152DKkDgrXeOeWe2QqE1HASgAf4I4T/ie/7R0STATdKwpR+Apt86hyMQbYq0CVpmlhbEYba9KK1IDozEuKcFXFV5+j8KJEOyl4ZBnbRbw9OJefrU/8TzniMXPrIxpMtc/I/aPQETMAlQGCEutXhdTsseonNsYqMrZ98tvkLbWfM8Qi1ufXir01xjAY0tz+ZzWKeDFJJ3wtcq9OrQ1MT1FHZd6HkArRtRp6sU4KOP7V0seZt8O0+Q8mvLaT92YQkeEYCql8fJsrnXYw3n8caXFA1FyJKRV9dO9SSODjFWz6DgbRyUiMdQTZ2MNLtydd0UXjUtDnzK/XAKQ8hwE4CZ8vrxFFnSnGZpLk81wvVbD6mU1ot2yVcG9aCRUzEBobWIEb/Rcz6wywtorg5e8QDUrVUt9E+Ksg3WjzsD4c6vzc63B2ELVIssR0KsC+Spcm5Kv5yDvEhICZ14z+kSSah1utKL/0+QNlL177hwcNvDsH+/3t9I1pPVuH3g+KsqaazpQwL0Gs4HvG0acv0vBWtemIUZvCEgyoRrU8JSTlJ9LvYlIzyl/mSin6zBi6JjUwXd9glmu9ffV3FCvd6smVSglfbiy/9wOKlIsLa54QY/hTbt8Ul644jlX0aDG1XVx8FqdBTvEDFoUrwqIx7Z/TtlP0Ry9gaxUQlWJanBxI435ikIMO0uMRYDeYh5ojxCnirHyoddEpecD6n1LdVSjF3eBvxpDIxu0WWNd/GKaKayw/UhpxDjiv6p3nmPj5iBaMnWLI4Yk2PtGzFjhbEF6nKiB0SWVsj8QYqCp9wEBNPXlGuE4qvL7N8IKjOepXNaO7+P3mWMrvcegHOG7qSBLaaiWW9lapfo9iDaDQJIsbuete35uUlb7iv5IGx7CSKbgDfdrYME7jqVRj2oZR8Qe+BvD/nQa+9Bdd0h4gaP9HVg/w==";     
                       String txt_today = String.Format("{0:yyyyMMdd}", DateTime.Today);// "20150321";
                       String hfStatus = "ACM";
                       String dateRange = "Year";
                       this.postdata = "ctl00$txt_stock_code=" + this.keyword + "&ctl00_txt_today=" + txt_today + "&ctl00_hfStatus=" + hfStatus + "&ctl00$sel_defaultDateRange=" + dateRange +"&__VIEWSTATEENCRYPTED="+"&__VIEWSTATE=" + HttpUtility.UrlEncode(viewstate);
                   
                        Thread thread = new Thread(new ThreadStart(postWebPageWorker));
                        thread.SetApartmentState(ApartmentState.STA);
                        thread.Start();
                        thread.Join();
                   }else{
                    Thread thread = new Thread(new ThreadStart(GetWebPageWorker));
                    thread.SetApartmentState(ApartmentState.STA);
                    thread.Start();
                    thread.Join();
                   }
            return this.temple;

        }

        protected void postWebPageWorker()
        {

           
            byte[] bytedata = Encoding.Default.GetBytes(this.postdata);


      
            using (WebBrowser browser = new WebBrowser())
            {

                //  browser.ClientSize = new Size(_width, _height);
                browser.ScrollBarsEnabled = false;
                browser.ScriptErrorsSuppressed = true;
                browser.AllowNavigation = true;
                browser.Navigate(new Uri(_url), string.Empty, bytedata, "Content-Type: application/x-www-form-urlencoded");
                browser.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(wb_DocumentCompleted);



                 while (browser.ReadyState != WebBrowserReadyState.Complete)
                {

                    Application.DoEvents();
                }
                 generateM22bTemple(browser.Document);

            }

        }
        //menu 2.2b
        protected void generateM22bTemple(HtmlDocument htmlDocument)
        {
            HtmlElementCollection hc = htmlDocument.GetElementsByTagName("table");
            String msg = "";
            Boolean containdata = false;
            HtmlElementCollection ahc=null;
            HtmlElementCollection stockHc=null;
            HtmlElementCollection tempHc=null;
            String stockname="";
            String stockCode="";
            for (int i = 0; i < hc.Count;i++ )
            {
                if (hc[i].GetAttribute("id") == "ctl00_gvMain")
                {
                    ahc = hc[i].GetElementsByTagName("a");
                    tempHc = hc[i].GetElementsByTagName("span");
                    containdata = true;
                    break;
                }
                else if (hc[i].GetAttribute("id") == "Table3")
                {
                    stockHc=hc[i].GetElementsByTagName("table")[0].GetElementsByTagName("span");
                }
            }
            if (stockHc!=null)
            {
                for (int i = 0; i < stockHc.Count;i++ )
                {
                    if (stockHc[i].GetAttribute("id") == "ctl00_lblStockName")
                    {
                      stockname=stockHc[i].InnerText;
                    }
                    if (stockHc[i].GetAttribute("id") == "ctl00_lblStockCode")
                    {
                        stockCode="("+stockHc[i].InnerText+")";
                    }
                }
            }
            int idindex = 3;
            int ahcindex = 0;
            int countItem = 0;
            int limit=5;
            String[] datestr=new String[limit];
            String[] shortxt=new String [limit];
            String[] title = new String[limit];
            String[] fileInfo = new String[limit];
            String[] link = new String[limit];
            

            if(containdata){

                msg = stockname+stockCode+"\n\n";
                
                for (int i = 0; i < tempHc.Count; i++)
                {
                    if (countItem == limit)
                    {
                        break;
                    }
                    if (tempHc[i].GetAttribute("id") == "ctl00_gvMain_ctl0" + idindex + "_lbDateTime")
                    {
                        datestr[countItem] = findTheMatchValue(tempHc[i].InnerText, @"[0-9a-z\/]+[^\\n]", 0) + " " + findTheMatchValue(tempHc[i].InnerText, @"[0-9]{0,}:[0-9]{0,}", 0) + "\n"; //date
                    }

                    if (tempHc[i].GetAttribute("id") == "ctl00_gvMain_ctl0" + idindex + "_lbShortText")
                    {
                        shortxt[countItem] = tempHc[i].InnerText + "\n";
                    }

                    if (tempHc[i].GetAttribute("id") == "ctl00_gvMain_ctl0"+idindex+"_hlTitle")
                    {
                        title[countItem] = tempHc[i].InnerText + "\n";
                    }
                    if (tempHc[i].GetAttribute("id") == "ctl00_gvMain_ctl0"+idindex+"_lbFileInfo")
                    {
                     
                        if (ahc[ahcindex].Id == "ctl00_gvMain_ctl0" + idindex + "_hlTitle")
                        {
                            link[countItem] = "<a href=\"" + ahc[ahcindex].GetAttribute("href") + "\"> " + ahc[ahcindex].InnerHtml + "</a>";
                        }
                        fileInfo[countItem] = tempHc[i].InnerText + "\n\n";
                        ahcindex++;
                        idindex++;
                        countItem++;
                    }
                    //ctl00_gvMain_ctl04_hlTitle
                    

                }

                for (int i = limit-1; i>0; i--)
                {
                    msg += datestr[i];
                    msg += shortxt[i];
                    msg += title[i];
                    msg += link[i];
                    msg += fileInfo[i];

                }
                msg += this.editable[this.menu];//"如您需要更多资料，请<a href=\"http://sc.hkexnews.hk/TuniS/www.hkexnews.hk/index_c.htm\">按此</a>。";
                this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", msg);
            }
            
        }

        protected void GetWebPageWorker()
        {
            HtmlDocument htmlDocument = getHtmlDocuemnt();
            switch (this.menu)
            {
                case "1.2":
                    generateM12Temple(htmlDocument);
                    break;
                case "2.1b":
                    generateM21bTemple(htmlDocument);
                    break;
                case "2.1c":
                  generateM21cTemple(htmlDocument);
                    break;
                case "3.2":
                    generateM32Temple(htmlDocument);
                    break;
            }
               

        }

       

        private void wb_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            WebBrowser wb = sender as WebBrowser;
            //this.htmlDocument = wb.Document;
            // wb.Document is not null at this point
        }
        private HtmlDocument getHtmlDocuemnt()
        {
            using (WebBrowser browser = new WebBrowser())
            {
                //  browser.ClientSize = new Size(_width, _height);
                browser.ScrollBarsEnabled = false;
                browser.ScriptErrorsSuppressed = true;
                browser.AllowNavigation = true;
                browser.Navigate(new Uri(_url));

                browser.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(wb_DocumentCompleted);

                // Wait for control to load page
                //while ((browser.IsBusy) | (browser.ReadyState != WebBrowserReadyState.Complete)) { Application.DoEvents(); }
                while (browser.ReadyState != WebBrowserReadyState.Complete)
                {

                    Application.DoEvents();
                }
                //this.temple=browser.DocumentText;
                 return browser.Document;
            }
        }
        // menu1.2
        private void generateM12Temple(HtmlDocument htmlDocument)
        {
            String[,] Rank = new String[2, 10];
            String[,] stockCode = new String[2, 10];
            String[,] stockName = new String[2, 10];
            String date = "";
            int index = 0;
            int subIndex = 0;

            HtmlElementCollection hc = htmlDocument.GetElementsByTagName("td");
            for (int i = 0; i < hc.Count; i++)
            {
                if (hc[i].GetElementsByTagName("div") != null && hc[i].GetElementsByTagName("div").Count != 0 && hc[i].GetElementsByTagName("div")[0].Id == "NBTitle1")
                {
                    index = 1;
                    subIndex = 0;
                }
                else if (hc[i].GetElementsByTagName("div") != null && hc[i].GetElementsByTagName("div").Count != 0 && hc[i].GetElementsByTagName("div")[0].Id == "SBTitle1")
                {
                    index = 0;
                    subIndex = 0;
                }
                if (hc[i].GetElementsByTagName("font") != null && hc[i].GetElementsByTagName("font").Count != 0 && hc[i].GetElementsByTagName("font")[0].InnerText.Length > 3 && hc[i].GetElementsByTagName("font")[0].InnerText.Substring(0, 2) == "日期")
                {
                    date = hc[i].GetElementsByTagName("font")[0].InnerText;
                }

                switch (hc[i].InnerText)
                {
                    case "1":
                    case "2":
                    case "3":
                    case "4":
                    case "5":
                    case "6":
                    case "7":
                    case "8":
                    case "9":
                    case "10":
                        Rank[index, subIndex] = assigeFixedlength(hc[i].InnerText, "0", 2, 0);
                        stockCode[index, subIndex] = hc[i + 1].InnerText;
                        stockName[index, subIndex] = hc[i + 2].InnerText;
                        subIndex++;
                        break;
                }
            }
            String msg = "";
            for (int i = 0; i < 2; i++)
            {
                for (int e = 0; e < subIndex; e++)
                {
                    if (i == 1)
                    {
                        if (e == 0)
                        {
                            msg += "\n沪股通成交活跃股\n(" + findTheMatchValue(date, @" (\b\d{1,2}/\d{1,2}/\d{1,4}\b)", 1) + ")\n" +
                             "排   " + "股票  " + "股票    \n" + "名   代碼  名稱\n";
                        }
                        msg += Rank[i, e] + "  " + stockCode[i, e] + " " + stockName[i, e] + "\n";
                    }
                    else if (i == 0)
                    {
                        if (e == 0)
                        {
                            msg += "港股通成交活跃股\n(" + findTheMatchValue(date, @" (\b\d{1,2}/\d{1,2}/\d{1,4}\b)", 1) + ")\n" +
                             "排   " + "股票  " + "股票    \n" + "名   代碼  名稱\n";
                        }
                        msg += Rank[i, e] + "  " + stockCode[i, e] + " " + stockName[i, e] + "\n";
                    }
                }
            }

            if (msg != "")
            {

                msg += this.editable[this.menu];//"\n以上为前一個交易日的交易资料。如您需要了解详细成交资料，请<a href=\"" + _url + "\">按此</a>";
                this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", msg);
            }

        }
        //menu 2.1b
        private void generateM21bTemple(HtmlDocument htmlDocument)
        {
            HtmlElementCollection hc = htmlDocument.GetElementsByTagName("table");
            Boolean containData = false;
            for (int tableIndex = 0; tableIndex < hc.Count; tableIndex++)
            {
                if (hc[tableIndex].FirstChild != null && hc[tableIndex].FirstChild.FirstChild != null && hc[tableIndex].FirstChild.FirstChild.FirstChild != null && hc[tableIndex].FirstChild.FirstChild.FirstChild.InnerText != null && hc[tableIndex].FirstChild.FirstChild.FirstChild.InnerText.Length > 2 && hc[tableIndex].FirstChild.FirstChild.FirstChild.InnerText.Substring(0, 2) == "最后")
                {
                    hc = hc[tableIndex].GetElementsByTagName("td");
                    containData = true;
                    break;
                }
            }
            if (containData == false)
            {
                this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", "No result");
                return;
            }

            String msg = "";
            String uploaddate = "";
            String stockname = "";
            String suspend = "";
            for (int i = 0; i < hc.Count; i++)
            {

                //if (hc[i].GetElementsByTagName("font") != null && hc[i].GetElementsByTagName("font").Count != 0 && hc[i].GetElementsByTagName("font")[0].InnerText != null && hc[i].GetElementsByTagName("font")[0].InnerText.Length > 2 && hc[i].GetElementsByTagName("font")[0].InnerText.Substring(0, 2) == "最后")
                //if (hc[i].FirstChild != null && hc[i].FirstChild.InnerText.Substring(0,2) == "最后")
                // {
                //msg = "";
                if (uploaddate == "")
                {
                    uploaddate = hc[i].GetElementsByTagName("font")[0].InnerText;
                    stockname = hc[i + 4].GetElementsByTagName("font")[0].InnerText;//stock name
                    if (hc[i + 4].GetElementsByTagName("font").Count == 2 && hc[i + 4].GetElementsByTagName("font")[1].InnerText != null && findTheMatchValue(hc[i + 4].GetElementsByTagName("font")[1].InnerText, @"[^\\\r\\\n]+\S", 0) == "停牌")
                    {
                        suspend = "<停牌>";
                    }
                }
                // }


                if (hc[i].GetElementsByTagName("font") != null && hc[i].GetElementsByTagName("font").Count != 0 && hc[i].GetElementsByTagName("b") != null && hc[i].GetElementsByTagName("b").Count != 0 && hc[i].GetElementsByTagName("b")[0].InnerText.Substring(0, 4) == "交易货币")
                {
                    String currency = findTheMatchValue(hc[i].GetElementsByTagName("b")[0].InnerText, @"([a-zA-Z]+)", 1);
                    String Nominal_Price = hc[i + 7].GetElementsByTagName("font")[0].InnerText;
                    String Net_Change = hc[i + 8].GetElementsByTagName("font")[0].InnerText;
                    String Change = hc[i + 9].GetElementsByTagName("font")[0].InnerText;
                    String Bid = hc[i + 10].GetElementsByTagName("font")[0].InnerText;
                    String Ask = hc[i + 11].GetElementsByTagName("font")[0].InnerText;

                    String High = hc[i + 20].GetElementsByTagName("font")[0].InnerText;
                    String Low = hc[i + 21].GetElementsByTagName("font")[0].InnerText;
                    String Share_Volume = hc[i + 23].GetElementsByTagName("font")[0].InnerText;
                    String Turnover = hc[i + 24].GetElementsByTagName("font")[0].InnerText;


                    msg += findTheMatchValue(stockname, @"\w*[^0-9\(]", 0) + "(" + assigeFixedlength(keyword, "0", 4, 0) + ")" + suspend + "\n";
                    /* if (suspend != string.Empty)
                     {
                         msg += suspend;
                     }*/
                    msg += "\n交易货币 " + currency + "\n";
                    msg += "按盘价 " + Nominal_Price + "\n";
                    msg += "升/跌 " + Net_Change + "\n";
                    msg += "变动(%) " + Change + "\n";
                    msg += "买入价 " + Bid + "\n";
                    msg += "卖出价 " + Ask + "\n";
                    msg += "最高价 " + High + "\n";
                    msg += "最低价 " + Low + "\n";
                    msg += "成交数量 (千) " + Share_Volume + "\n";
                    msg += "成交金额 (千元) " + Turnover + "\n\n";
                    msg += uploaddate + "\n\n";
                    msg += this.editable[this.menu]; ;
                    //msg += "以上资料最少延时15分钟。\n";
                    //msg += "成交资料於开市前时段的对盘时段结束十五分钟后提供。";

                    // this.temple = currency + " " + Nominal_Price + " " + Net_Change + " " + Change + " " + Bid + " " + Ask + " " + High + " " + Low + " " + Share_Volume + " " + Turnover + " " + lastStatement;
                    
                }
            }
            if (msg != "")
            {
                this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", msg);
            }
        }
        //menu 2.1c
        private void generateM21cTemple(HtmlDocument htmlDocument)
        {
            HtmlElementCollection hc = htmlDocument.GetElementsByTagName("body");
            Boolean containData = false;
            for (int tableIndex = 0; tableIndex < hc.Count; tableIndex++)
            {
                if (hc[tableIndex].FirstChild != null && hc[tableIndex].FirstChild.FirstChild != null && hc[tableIndex].FirstChild.FirstChild.FirstChild != null && hc[tableIndex].FirstChild.FirstChild.FirstChild.InnerText == "代号")
                {
                    hc = hc[tableIndex].GetElementsByTagName("td");
                    containData = true;
                    break;
                }
            }



            if (containData == false)
            {
                this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", "No result");
                return;
            }
            String msg = "";
            for (int i = 0; i < hc.Count; i++)
            {
              
                if (hc[i].GetElementsByTagName("font") != null && hc[i].GetElementsByTagName("font").Count != 0 && hc[i].GetElementsByTagName("font")[0].InnerText == "上市公司名称")
                {
                    //hc = hc[i].GetElementsByTagName("font");
                    int distance = i + 2;
                    int column = 6;
                    int count = 0;
                    while (distance < hc.Count && hc[distance].GetElementsByTagName("font") != null && hc[distance].GetElementsByTagName("font").Count != 0)
                    {
                        if (count == 10)
                        {
                            break;
                        }
                        int stockCode;
                        bool valid = Int32.TryParse(hc[distance].GetElementsByTagName("font")[0].InnerText, out stockCode);
                        if (valid)
                        {

                            //if (stockCode.ToString().Length != 5)
                            // {
                            msg += assigeFixedlength(stockCode.ToString(), "0", 5, 0) + "  ";

                            if (hc[distance + 1].GetElementsByTagName("font") != null && hc[distance + 1].GetElementsByTagName("font").Count != 0)
                            {
                                msg += hc[distance + 1].GetElementsByTagName("font")[0].InnerText + "\n";
                            }
                            //}
                            count++;
                        }
                        distance = distance + column;
                    }
                    break;
                }
            }

            if (msg != "")
            {
                string header = "代号      上市公司名称\n";
                String footer = this.editable[this.menu];
                //string footer = "\n证券查询：请直接回复“证券代号”。";
                this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", header + msg +"\n"+ footer);

            }
            else
            {
                this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", "No result");
            }

            //  debugstr += msg="\n";
            //this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", msg);

        }

        //menu3.2 blog
        private void generateM32Temple(HtmlDocument htmlDocument){
              HtmlElementCollection hc = htmlDocument.GetElementsByTagName("table");
                    Boolean containData = false;
                    String msg = "";
                    String newsItem = "";
                    for (int tableIndex = 0; tableIndex < hc.Count; tableIndex++)
                    {
                        if (hc[tableIndex].GetElementsByTagName("td") != null && hc[tableIndex].GetElementsByTagName("td").Count != 0 && hc[tableIndex].GetElementsByTagName("td")[0].InnerHtml == "网志档案")
                        {
                            hc = hc[tableIndex].GetElementsByTagName("td");
                            containData = true;
                            break;
                        }
                    }
                    if (containData)
                    {
                        int count = 0;
                        for (int i = 1; i < hc.Count; i++) //0 is 网志档案
                        {
                            if (count == 5)
                            {
                                break;
                            }
                            else if (hc[i].InnerText.Trim() != null && hc[i].InnerText.Trim()!=String.Empty)
                            {
                                String blog = hc[i].InnerText;
                                String url = hc[i].GetElementsByTagName("a")[0].GetAttribute("href");

                                if(count==0){
                                newsItem += "<item>" +
                                             "<Title><![CDATA["+blog+"]]></Title>" +
                                             "<Description><![CDATA[Description]]></Description>" +
                                             "<PicUrl><![CDATA[http://www.hkex.com.hk/chi/newsconsul/blog/image/HKEx_banner1230_v8_c.jpg]]></PicUrl>" +
                                             "<Url><![CDATA[" + url + "]]></Url>" +
                                             "</item>";
                                }else{
                                    newsItem += "<item>" +
                                             "<Title><![CDATA[" + blog + "]]></Title>" +
                                             "<Description><![CDATA[Description]]></Description>" +
                                             "<PicUrl><![CDATA[]]></PicUrl>" +
                                             "<Url><![CDATA[" + url + "]]></Url>" +
                                             "</item>";
                                }

                                count++;
                            }
                        }
                        this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, newsItem);
                        //this.temple = String.Format(defaultTemple, fromUserName, toUserName, createtime, "text", msg);

                    }
        }
        
        public string assigeFixedlength(String word, string prefix, int Totallength, int beforeAfter)
        {
            String prefixstr = "";
            int difflength = Totallength - word.Length;
            if (difflength <= 0)
            {
                return word.Substring(0, Totallength);
            }
            for (int i = 0; i < difflength; i++)
            {
                prefixstr += prefix;
            }

            if (beforeAfter > 0)//after word
            {
                return word + prefixstr;
            }
            else//before word
            {
                return prefixstr + word;
            }
        }

        public string findTheMatchValue(string htmlCode, string regexStr, int index)
        {

            //Match m = Regex.Match(htmlcode, @"<title>\s*(.+?)\s*</title>");
            Match m = Regex.Match(htmlCode, regexStr);
            if (m.Success)
            {
                return m.Groups[index].Value;
            }
            else
            {
                return "";
            }

        }


        public string[] findTheMatchValues(string htmlCode, string regexStr, int[] index)
        {
            Match m = Regex.Match(htmlCode, regexStr);
            string[] matchedValue = new String[index.Length];
            for (int i = 0; i < index.Length; i++)
            {

                if (m.Success)
                {
                    matchedValue[i] = m.Groups[index[i]].Value;
                }
                else
                {
                    matchedValue[i] = "";
                }

            }
            return matchedValue;
        }


        //for debug
        public void log(String message)
        {
            string mydocpath = "C:/debug/";
            string filename = String.Format("{0:yyyyMMdd}", DateTime.Today) + ".txt";
            StringBuilder sb = new StringBuilder();
            String path = mydocpath + filename;
            // Enumerate the files in the My Documents path, filtering for text files only. 

            if (!File.Exists(path))
            {

                using (StreamWriter sw = File.CreateText(path))
                {
                    sb.AppendLine(DateTime.Today.ToString() + " " + message);
                    sb.AppendLine("= = = = = =");
                }
            }
            else
            {

                using (StreamReader sr = new StreamReader(path))
                {
                    sb.AppendLine(DateTime.Today.ToString() + " " + message);
                    sb.AppendLine("= = = = = =");
                    sb.Append(sr.ReadToEnd());
                    sb.AppendLine();
                }

                using (StreamWriter outfile = new StreamWriter(path))
                {
                    outfile.Write(sb.ToString());
                }
            }

        }
    }
}