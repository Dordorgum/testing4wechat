﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace WechatAuthorization
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            weixin wx = new weixin();
            if (Request.HttpMethod.ToLower() == "post")
            {

            }

            else
            {
                wx.Auth();
            }

        }
    }


    public class weixin
    {
        //wxdef363a5d71f854f 
        //b5a9680c89589d34a1b162726a3cd0b6
        //NS054wsv9C9vjXLCkzOtC1ImLR9yTErR_vYdVyy_QQR_4gTy-JjT1iCirPPnAHdD4jx6-Hj6aKaOrH1FQ55YAJ3rPlzwrCPrVzFU7hLzoVw

        //for actual id wx6a6eaf0c4456af06
        //secret  9fb1078ca64247ffc09b74cd011077a1

        private string weChatAppID = "wxdef363a5d71f854f";
        private string weChatAppSecret = "b5a9680c89589d34a1b162726a3cd0b6";
        //public string weChatAccessToken;
        private string menuResult;

        //public String echoStrr;



        public void Auth()
        {

            string echoStr = System.Web.HttpContext.Current.Request.QueryString["echoStr"];

            if (CheckSignature())
            {

                if (!string.IsNullOrEmpty(echoStr))
                {


                    System.Web.HttpContext.Current.Response.Write(echoStr);

                    System.Web.HttpContext.Current.Response.End();



                }

            }


            // return menuResult;
        }




        private bool CheckSignature()
        {

            string Token = "weixin";
            string signature = System.Web.HttpContext.Current.Request.QueryString["signature"];
            // menuResult = signature;
            string timestamp = System.Web.HttpContext.Current.Request.QueryString["timestamp"];

            string nonce = System.Web.HttpContext.Current.Request.QueryString["nonce"];

            string[] ArrTmp = { Token, timestamp, nonce };

            Array.Sort(ArrTmp);

            string tmpStr = string.Join("", ArrTmp);

            tmpStr = FormsAuthentication.HashPasswordForStoringInConfigFile(tmpStr, "SHA1");

            tmpStr = tmpStr.ToLower();

            if (tmpStr == signature)
            {
                return true;

            }

            else
            {
                //  log("signature don't equal to SHA1(tmpStr)!!");
                return false;

            }

        }

    }
}